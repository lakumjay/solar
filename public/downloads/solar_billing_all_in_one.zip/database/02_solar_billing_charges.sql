-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for osx10.10 (x86_64)
--
-- Host: 127.0.0.1    Database: snweba2e_jay_solar
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `solar_billing_charges`
--

DROP TABLE IF EXISTS `solar_billing_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solar_billing_charges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `type` enum('charge','rebate') NOT NULL,
  `calc_basis` enum('per_unit','per_banking_unit','per_peak_unit','per_gen_unit','pct_energy','pct_energy_fca','pct_board','fixed') NOT NULL,
  `value` decimal(12,4) NOT NULL,
  `company_id` bigint(20) unsigned DEFAULT NULL,
  `effective_from` date NOT NULL DEFAULT '2026-01-01',
  `effective_to` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `solar_billing_charges_company_id_foreign` (`company_id`),
  KEY `solar_billing_charges_code_is_active_effective_from_index` (`code`,`is_active`,`effective_from`),
  CONSTRAINT `solar_billing_charges_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `solar_billing_companies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solar_billing_charges`
--

LOCK TABLES `solar_billing_charges` WRITE;
/*!40000 ALTER TABLE `solar_billing_charges` DISABLE KEYS */;
INSERT INTO `solar_billing_charges` VALUES (1,'Cross Subsidy','cross_subsidy','rebate','pct_energy_fca',15.0000,NULL,'2026-01-01',NULL,1,1,'2026-10-29 13:59:49','2026-10-29 13:59:49'),(2,'Wheeling Charge','wheeling','rebate','per_gen_unit',0.2352,NULL,'2026-01-01',NULL,1,2,'2026-10-29 13:59:49','2026-10-29 13:59:49'),(3,'Banking Charge','banking','rebate','per_banking_unit',1.5000,NULL,'2026-01-01',NULL,1,3,'2026-10-29 13:59:49','2026-10-29 13:59:49'),(4,'Discount (PPA)','ppa_discount','rebate','per_unit',1.2500,NULL,'2026-01-01',NULL,1,4,'2026-10-29 13:59:49','2026-10-29 13:59:49');
/*!40000 ALTER TABLE `solar_billing_charges` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-29 21:48:47
