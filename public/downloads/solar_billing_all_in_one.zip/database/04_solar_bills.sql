-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for osx10.10 (x86_64)
--
-- Host: 127.0.0.1    Database: snweba2e_jay_solar
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `solar_bills`
--

DROP TABLE IF EXISTS `solar_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solar_bills` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `month` varchar(30) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `invoice_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_address` text DEFAULT NULL,
  `customer_gstin` varchar(50) DEFAULT NULL,
  `units_credited` decimal(15,2) NOT NULL,
  `units_peak` decimal(15,2) NOT NULL DEFAULT 0.00,
  `units_banking` decimal(15,2) NOT NULL DEFAULT 0.00,
  `units_generated` decimal(15,2) NOT NULL,
  `stmt_inputs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`stmt_inputs`)),
  `rates_derived` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`rates_derived`)),
  `extra_params` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`extra_params`)),
  `breakdown` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`breakdown`)),
  `sub_total` decimal(15,2) NOT NULL,
  `discount_rate` decimal(8,2) NOT NULL DEFAULT 1.25,
  `discount_amt` decimal(15,2) NOT NULL DEFAULT 0.00,
  `prev_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `prev_invoice_no` varchar(255) DEFAULT NULL,
  `interest_amt` decimal(15,2) NOT NULL DEFAULT 0.00,
  `interest_days` int(10) unsigned NOT NULL DEFAULT 0,
  `interest_waived` decimal(12,2) NOT NULL DEFAULT 0.00,
  `interest_waive_reason` text DEFAULT NULL,
  `interest_waived_by` bigint(20) unsigned DEFAULT NULL,
  `interest_waived_at` datetime DEFAULT NULL,
  `round_off` decimal(6,2) NOT NULL DEFAULT 0.00,
  `current_grand_total` decimal(15,2) NOT NULL,
  `total_outstanding` decimal(15,2) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `paid_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `paid_at` timestamp NULL DEFAULT NULL,
  `voided_at` timestamp NULL DEFAULT NULL,
  `voided_by` bigint(20) unsigned DEFAULT NULL,
  `void_reason` text DEFAULT NULL,
  `pdf_path` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `solar_bills_invoice_no_unique` (`invoice_no`),
  KEY `solar_bills_voided_by_foreign` (`voided_by`),
  KEY `solar_bills_created_by_foreign` (`created_by`),
  KEY `solar_bills_company_id_status_invoice_date_index` (`company_id`,`status`,`invoice_date`),
  KEY `solar_bills_month_status_index` (`month`,`status`),
  KEY `solar_bills_interest_waived_by_foreign` (`interest_waived_by`),
  CONSTRAINT `solar_bills_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `solar_billing_companies` (`id`),
  CONSTRAINT `solar_bills_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `solar_bills_interest_waived_by_foreign` FOREIGN KEY (`interest_waived_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `solar_bills_voided_by_foreign` FOREIGN KEY (`voided_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solar_bills`
--

LOCK TABLES `solar_bills` WRITE;
/*!40000 ALTER TABLE `solar_bills` DISABLE KEYS */;
INSERT INTO `solar_bills` VALUES (1,1,'Aug-26','RS/26-27/01','2026-09-05','2026-09-20','Blueart Granito Pvt. Ltd.','S. NO. 93/1P3, B/H. KEDA CERAMIC, PANELI ROAD,\nTAL. MORBI, JAMBUDIYA\nMorbi - 363642','24AABCO3285B1ZU',105715.00,31708.00,20113.00,113064.17,'{\"unit\":166107,\"energyAmt\":697649.4,\"fcaAmt\":406962.15,\"pfAmt\":14301.81,\"ehvAmt\":6976.49,\"touAmt\":41995.95,\"totalPeak\":49407,\"varAmt\":44074,\"boardAmt\":1169403.19,\"dutyAmt\":175410.48}','{\"energyRate\":4.2,\"fcaRate\":2.45,\"pfPct\":2.0499996129861215,\"ehvPct\":0.9999994266461062,\"touRate\":0.85,\"varPct\":3.98999992350252,\"dutyPct\":15.00000012827056}','{\"lossPct\":6.5,\"crossPct\":15,\"wheelRate\":0.2352,\"bankRate\":1.5}','{\"generated\":113064.17,\"energy\":444003,\"fca\":259001.75,\"pf\":9102.06,\"ehv\":4440.03,\"tou\":26951.8,\"variable\":28049.89,\"board\":744464.35,\"duty\":111669.65,\"total\":856134.01,\"cross\":105450.71,\"wheeling\":26592.69,\"banking\":30169.5,\"net\":693921.1,\"billRate\":6.564074160911632,\"netRate\":5.314074160911632,\"discountAmt\":132143.75,\"roundOff\":-0.35,\"grand\":561777,\"warnings\":[]}',693921.10,1.25,132143.75,0.00,NULL,0.00,0,0.00,NULL,NULL,NULL,-0.35,561777.00,561777.00,'pending',0.00,NULL,NULL,NULL,NULL,'billing_statements/Blueart_granito_Aug26.pdf',NULL,1,'2026-10-29 11:39:19','2026-10-29 11:39:19'),(2,2,'Aug-26','SUN/26-27/01','2026-09-05','2026-09-20','Blueart Granito Pvt. Ltd.','S. NO. 93/1P3, B/H. KEDA CERAMIC, PANELI ROAD,\nTAL. MORBI, JAMBUDIYA\nMorbi - 363642','24AABCO3285B1ZU',60392.00,17699.00,11497.00,64590.37,'{\"unit\":166107,\"energyAmt\":697649.4,\"fcaAmt\":406962.15,\"pfAmt\":14301.81,\"ehvAmt\":6976.49,\"touAmt\":41995.95,\"totalPeak\":49407,\"varAmt\":44074,\"boardAmt\":1169403.19,\"dutyAmt\":175410.48}','{\"energyRate\":4.2,\"fcaRate\":2.45,\"pfPct\":2.0499996129861215,\"ehvPct\":0.9999994266461062,\"touRate\":0.85,\"varPct\":3.98999992350252,\"dutyPct\":15.00000012827056}','{\"lossPct\":6.5,\"crossPct\":15,\"wheelRate\":0.2352,\"bankRate\":1.5}','{\"generated\":64590.37,\"energy\":253646.4,\"fca\":147960.4,\"pf\":5199.75,\"ehv\":2536.46,\"tou\":15044.15,\"variable\":16024.11,\"board\":424938.85,\"duty\":63740.83,\"total\":488679.68,\"cross\":60241.02,\"wheeling\":15191.66,\"banking\":17245.5,\"net\":396001.5,\"billRate\":6.557184726260397,\"netRate\":5.307184726260397,\"discountAmt\":75490,\"roundOff\":-0.5,\"grand\":320511,\"warnings\":[]}',396001.50,1.25,75490.00,0.00,NULL,0.00,0,0.00,NULL,NULL,NULL,-0.50,320511.00,320511.00,'pending',0.00,NULL,NULL,NULL,NULL,'billing_statements/Blueart_granito_Aug26.pdf',NULL,1,'2026-10-29 11:39:19','2026-10-29 11:39:19');
/*!40000 ALTER TABLE `solar_bills` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-29 21:48:47
