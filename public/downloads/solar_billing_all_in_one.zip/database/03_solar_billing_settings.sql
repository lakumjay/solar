-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for osx10.10 (x86_64)
--
-- Host: 127.0.0.1    Database: snweba2e_jay_solar
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `solar_billing_settings`
--

DROP TABLE IF EXISTS `solar_billing_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solar_billing_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `solar_billing_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solar_billing_settings`
--

LOCK TABLES `solar_billing_settings` WRITE;
/*!40000 ALTER TABLE `solar_billing_settings` DISABLE KEYS */;
INSERT INTO `solar_billing_settings` VALUES (1,'default_discount','1.25','2026-10-29 08:20:38','2026-10-29 08:20:38'),(2,'interest_pct','18.00','2026-10-29 08:20:38','2026-10-29 08:20:38'),(3,'loss_pct','6.50','2026-10-29 08:20:38','2026-10-29 08:20:38'),(4,'due_days','15','2026-10-29 08:20:38','2026-10-29 08:20:38'),(5,'cross_pct','15.00','2026-10-29 08:20:38','2026-10-29 08:20:38'),(6,'wheel_rate','0.2352','2026-10-29 08:20:38','2026-10-29 08:20:38'),(7,'default_customer_name','Blueart Granito Pvt. Ltd.','2026-10-29 08:20:38','2026-10-29 08:20:38'),(8,'default_customer_address','S.No. 93/1P3, B/h. Keda Ceramic, Paneli Road, Morbi-363642','2026-10-29 08:20:38','2026-10-29 08:20:38'),(9,'default_customer_gstin','24AABCO3285B1ZU','2026-10-29 08:20:38','2026-10-29 08:20:38'),(10,'signature_url','','2026-10-29 08:20:38','2026-10-29 08:20:38');
/*!40000 ALTER TABLE `solar_billing_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-29 21:48:47
