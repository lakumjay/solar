-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for osx10.10 (x86_64)
--
-- Host: 127.0.0.1    Database: snweba2e_jay_solar
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `solar_billing_companies`
--

DROP TABLE IF EXISTS `solar_billing_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solar_billing_companies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `gstin` varchar(30) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phones` varchar(100) DEFAULT NULL,
  `bank_name` varchar(150) DEFAULT NULL,
  `bank_ac` varchar(50) DEFAULT NULL,
  `bank_ifsc` varchar(30) DEFAULT NULL,
  `discount` decimal(8,2) DEFAULT NULL,
  `inv_prefix` varchar(20) NOT NULL DEFAULT 'RS',
  `last_seq` int(10) unsigned NOT NULL DEFAULT 0,
  `logo_path` varchar(255) DEFAULT NULL,
  `signature_path` varchar(255) DEFAULT NULL,
  `signature_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `letterhead_path` varchar(255) DEFAULT NULL,
  `letterhead_mode` varchar(30) NOT NULL DEFAULT 'digital',
  `due_days` int(10) unsigned DEFAULT 15,
  `interest_pct` decimal(5,2) DEFAULT 18.00,
  `loss_pct` decimal(5,2) DEFAULT 6.50,
  `wheel_rate` decimal(8,4) DEFAULT 0.2352,
  `bank_rate` decimal(8,4) DEFAULT 1.5000,
  `cross_pct` decimal(5,2) DEFAULT 15.00,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solar_billing_companies`
--

LOCK TABLES `solar_billing_companies` WRITE;
/*!40000 ALTER TABLE `solar_billing_companies` DISABLE KEYS */;
INSERT INTO `solar_billing_companies` VALUES (1,'RAJESHWARI SOLAR','24ABJFR7554G1ZX','Plot No-131, Panchpada, Paliyad Road, Shivajinagar, Botad-364710','6353116138, 9924283670','State Bank of India, Paliyad Road, Botad','44295348601','SBIN0005946',1.25,'RS',1,'/images/companies/rajeshwari-logo.png',NULL,1,NULL,'digital',15,18.00,6.50,0.2352,1.5000,15.00,1,'2026-10-29 08:20:38','2026-10-29 12:56:22'),(2,'SUNRISE GREEN ENERGY','24FFNPP9576P1Z4','Plot No-131, Panchpada, Paliyad Road, Shivajinagar, Botad-364710','6353116138, 9924283670','State Bank of India','44588738053','SBIN0005946',1.25,'SUN',1,'/images/companies/sunrise-logo.png',NULL,1,NULL,'digital',15,18.00,6.50,0.2352,1.5000,15.00,1,'2026-10-29 08:20:38','2026-10-29 12:56:22'),(3,'NILKANTH GREEN ENERGY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NIL',0,NULL,NULL,1,NULL,'digital',15,18.00,6.50,0.2352,1.5000,15.00,1,'2026-10-29 08:20:38','2026-10-29 08:20:38');
/*!40000 ALTER TABLE `solar_billing_companies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-29 21:48:47
