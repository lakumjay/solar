import React, {useEffect, useMemo, useState} from 'react';
import {ClockAlert, ExternalLink, MapPin, Navigation, PencilLine, Plus, Radio, RefreshCw, Search, Smartphone, User, X} from 'lucide-react';
import {api, resolveMediaUrl} from '../api';
import { getLanguage, t } from '../utils/translations';
import {DatePicker, Empty, Field} from '../components/Common';

const localDate = () => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
};
const today = localDate;
const localDateTime = (value, date, fallback = '18:00') => {
    if (!value) return `${date}T${fallback}`;
    const parsed = new Date(value);
    return `${parsed.getFullYear()}-${String(parsed.getMonth() + 1).padStart(2, '0')}-${String(parsed.getDate()).padStart(2, '0')}T${String(parsed.getHours()).padStart(2, '0')}:${String(parsed.getMinutes()).padStart(2, '0')}`;
};
const displayTime = value => value ? new Date(value).toLocaleTimeString('en-US', {hour: '2-digit', minute: '2-digit', hour12: true}) : 'Missing';

export default function AttendancePage({canCorrect, canRecord}) {
    const [currentLang, setCurrentLang] = useState(getLanguage());

    useEffect(() => {
        const handleLangChange = (e) => setCurrentLang(e.detail);
        window.addEventListener('solarflow_language_change', handleLangChange);
        return () => window.removeEventListener('solarflow_language_change', handleLangChange);
    }, []);
    const [employees, setEmployees] = useState([]);
    const [rows, setRows] = useState([]);
    const [date, setDate] = useState(localDate());
    const [employeeId, setEmployeeId] = useState('');
    const [search, setSearch] = useState('');
    const [correction, setCorrection] = useState(null);
    const [manual, setManual] = useState(null);
    const [savingManual, setSavingManual] = useState(false);
    const [savingCorrection, setSavingCorrection] = useState(false);
    const [selfiePreview, setSelfiePreview] = useState(null);
    const [message, setMessage] = useState('');
    const [viewMode, setViewMode] = useState('cards');

    // 📍 Real-Time Live Employee Locations
    const [liveLocations, setLiveLocations] = useState([]);
    const [liveCount, setLiveCount] = useState(0);
    const [loadingLocations, setLoadingLocations] = useState(false);
    const [selectedMapEmployee, setSelectedMapEmployee] = useState(null);
    const [mapMode, setMapMode] = useState('satellite'); // 'satellite' | 'roadmap'
    const [zoomLevel, setZoomLevel] = useState(20); // 20 is ultra close-up satellite level
    const [allLeaves, setAllLeaves] = useState([]);
    const [leaveFilter, setLeaveFilter] = useState('active'); // 'active' (Today/Tomorrow/Pending/Upcoming) | 'pending' | 'approved' | 'history' | 'all'
    const [reviewingLeaveId, setReviewingLeaveId] = useState(null);

    const todayStr = useMemo(() => localDate(), []);
    const yesterdayStr = useMemo(() => {
        const d = new Date();
        d.setDate(d.getDate() - 1);
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    }, []);

    // Check if leave is active for today/tomorrow/upcoming, pending, or recently requested
    const isLeaveActiveOrRecent = useMemo(() => {
        return (leave) => {
            if (!leave) return false;
            // 1. All pending leaves MUST be shown so admin can approve or reject
            if (leave.status === 'pending') return true;

            // 2. Active today or upcoming in future (date_to >= today)
            const endDate = leave.date_to || leave.date_from;
            if (endDate && endDate >= todayStr) return true;

            // 3. Requested / created today or yesterday
            const createdDate = leave.created_at ? leave.created_at.slice(0, 10) : null;
            if (createdDate && createdDate >= yesterdayStr) return true;

            // Past accepted/rejected leaves that ended before today are considered old history
            return false;
        };
    }, [todayStr, yesterdayStr]);

    const pendingLeaves = useMemo(() => allLeaves.filter(l => l.status === 'pending'), [allLeaves]);
    const activeLeaves = useMemo(() => allLeaves.filter(isLeaveActiveOrRecent), [allLeaves, isLeaveActiveOrRecent]);
    const pastLeaves = useMemo(() => allLeaves.filter(l => !isLeaveActiveOrRecent(l)), [allLeaves, isLeaveActiveOrRecent]);

    const loadLiveLocations = async () => {
        try {
            setLoadingLocations(true);
            const data = await api('employee-locations/live');
            setLiveLocations(data.employees || []);
            setLiveCount(data.live_count || 0);
        } catch (e) {
            console.warn('Live location error', e);
        } finally {
            setLoadingLocations(false);
        }
    };

    const displayLocations = useMemo(() => {
        if (liveLocations && liveLocations.length > 0) {
            return liveLocations;
        }
        if (employees && employees.length > 0) {
            return employees
                .filter(emp => !emp.manager_attendance_only)
                .map(emp => {
                const row = rows.find(r => String(r.employee_id) === String(emp.id) || String(r.employee?.id) === String(emp.id));
                const lat = row && row.clock_in_latitude && Number(row.clock_in_latitude) !== 0 ? Number(row.clock_in_latitude) : null;
                const lng = row && row.clock_in_longitude && Number(row.clock_in_longitude) !== 0 ? Number(row.clock_in_longitude) : null;
                const isLive = Boolean(row && !row.clock_out_at && lat);
                return {
                    employee_id: emp.id,
                    name: emp.name || emp.user?.name || 'Employee',
                    employee_code: emp.employee_code,
                    designation: emp.designation || 'Field Officer',
                    company_name: 'SolarFlow Shared',
                    company_id: null,
                    avatar_url: emp.profile_photo_url || null,
                    is_live: isLive,
                    last_seen: row ? (currentLang === 'en' ? 'Synced from Time In' : 'Time In પરથી સિંક') : (currentLang === 'en' ? 'Waiting for GPS ping' : 'GPS પિંગની રાહ જુએ છે'),
                    status: row ? (row.clock_out_at ? 'Shift Ended' : 'Working') : 'Not Checked In',
                    latitude: lat,
                    longitude: lng,
                    accuracy: row?.clock_in_accuracy || 15,
                    speed: isLive ? 0 : null,
                    movement: isLive ? 'stationary' : 'offline',
                    movement_icon: isLive ? '🧍‍♂️' : '⚪',
                    movement_label: isLive ? (currentLang === 'en' ? 'Stationary on site (0 km/h)' : 'સાઇટ પર સ્થિર (0 km/h)') : (currentLang === 'en' ? 'Offline' : 'ઑફલાઇન'),
                    map_url: lat && lng ? `https://www.google.com/maps?q=${lat},${lng}` : null,
                };
            });
        }
        return [];
    }, [liveLocations, employees, rows]);

    const activeLiveCount = useMemo(() => {
        return displayLocations.filter(e => e.is_live).length;
    }, [displayLocations]);

    const load = async () => {
        const query = new URLSearchParams({date});
        if (employeeId) query.set('employee_id', employeeId);
        const [attendanceRes, peopleRes, leavesRes] = await Promise.allSettled([
            api(`attendance?${query}`),
            api('employees'),
            api('leaves')
        ]);
        if (attendanceRes.status === 'fulfilled') setRows(attendanceRes.value || []);
        if (peopleRes.status === 'fulfilled') setEmployees(peopleRes.value || []);
        if (leavesRes.status === 'fulfilled') setAllLeaves(leavesRes.value || []);
        if (attendanceRes.status === 'rejected') setMessage(attendanceRes.reason?.message || 'Failed to load attendance.');
    };

    const handleReviewLeave = async (leave, decision) => {
        const remarks = window.prompt(
            decision === 'approved'
                ? (currentLang === 'en' ? 'Approval remarks (optional):' : 'મંજૂરી નોંધ / રીમાર્ક્સ (ઓપ્શનલ):')
                : (currentLang === 'en' ? 'Rejection reason:' : 'નામંજૂર કરવાનું કારણ:')
        );
        if (remarks === null) return;
        setReviewingLeaveId(leave.id);
        try {
            await api(`leaves/${leave.id}/review`, {
                method: 'POST',
                body: JSON.stringify({status: decision, remarks})
            });
            setMessage(
                currentLang === 'en'
                    ? `Leave request ${decision} successfully.`
                    : `રજાની અરજી સફળતાપૂર્વક ${decision === 'approved' ? 'મંજૂર (Approved)' : 'નામંજૂર (Rejected)'} કરવામાં આવી.`
            );
            await load();
        } catch (err) {
            setMessage(err.message || 'Error reviewing leave request.');
        } finally {
            setReviewingLeaveId(null);
        }
    };

    useEffect(() => {
        load().catch(error => setMessage(error.message));
        loadLiveLocations();
        const locInterval = setInterval(() => {
            if (typeof document !== 'undefined' && !document.hidden) {
                loadLiveLocations();
            }
        }, 30000);
        const handleVisibility = () => {
            if (!document.hidden) {
                loadLiveLocations();
            }
        };
        document.addEventListener('visibilitychange', handleVisibility);
        return () => {
            clearInterval(locInterval);
            document.removeEventListener('visibilitychange', handleVisibility);
        };
    }, [date, employeeId]);

    const filtered = useMemo(() => (rows || []).filter(row => {
        const empName = row.employee?.user?.name || row.employee?.name || '';
        const empCode = row.employee?.employee_code || '';
        return `${empName} ${empCode}`.toLowerCase().includes((search || '').toLowerCase());
    }), [rows, search]);

    const openCorrection = row => setCorrection({
        id: row.id,
        employee: row.employee?.user?.name || row.employee?.name || 'Employee',
        attendance_date: row.attendance_date,
        clock_out_at: localDateTime(row.clock_out_at, row.attendance_date, row.employee?.shift_end?.slice(0, 5) || '18:00'),
        work_done: row.work_done || '',
        learned: row.learned || '',
        correction_reason: '',
        had_clock_out: Boolean(row.clock_out_at),
    });

    const saveCorrection = async event => {
        event.preventDefault();
        setMessage('');
        setSavingCorrection(true);
        try {
            await api(`attendance/${correction.id}/correct`, {method: 'POST', body: JSON.stringify(correction)});
            setCorrection(null);
            setMessage('Attendance correction saved with audit history.');
            await load();
        } catch (error) { setMessage(error.message); }
        finally { setSavingCorrection(false); }
    };
    const eligibleEmployees = employees.filter(employee => employee.active && employee.manager_attendance_only);
    const openManual = () => {
        const employee = eligibleEmployees.find(item => String(item.id) === String(employeeId)) || eligibleEmployees[0];
        if (!employee) return setMessage('Mark an active employee as “Manager records attendance” first.');
        const attendanceDate = date > localDate() ? localDate() : date;
        setManual({
            employee_id: String(employee.id),
            attendance_date: attendanceDate,
            clock_in_at: `${attendanceDate}T${employee.shift_start?.slice(0, 5) || '09:00'}`,
            clock_out_at: `${attendanceDate}T${employee.shift_end?.slice(0, 5) || '18:00'}`,
            break_minutes: 0,
            work_done: '',
            learned: '',
            entry_reason: '',
        });
        setMessage('');
    };
    const changeManualEmployee = value => {
        const employee = eligibleEmployees.find(item => String(item.id) === String(value));
        setManual(current => ({...current, employee_id: value, clock_in_at: `${current.attendance_date}T${employee?.shift_start?.slice(0, 5) || '09:00'}`, clock_out_at: `${current.attendance_date}T${employee?.shift_end?.slice(0, 5) || '18:00'}`}));
    };
    const changeManualDate = value => setManual(current => ({...current, attendance_date: value, clock_in_at: `${value}T${current.clock_in_at.slice(11, 16)}`, clock_out_at: `${value}T${current.clock_out_at.slice(11, 16)}`}));
    const saveManual = async event => {
        event.preventDefault();
        setMessage('');
        setSavingManual(true);
        try {
            await api('attendance/manual', {method: 'POST', body: JSON.stringify({...manual, employee_id: Number(manual.employee_id), break_minutes: Number(manual.break_minutes)})});
            setManual(null);
            setMessage('Manager-entered attendance saved with audit history.');
            await load();
        } catch (error) { setMessage(error.message); }
        finally { setSavingManual(false); }
    };
    const todayDate = localDate();
    const isToday = date === todayDate;
    const [showLiveMaps, setShowLiveMaps] = useState(true);
    const [quickSelectEmpId, setQuickSelectEmpId] = useState(null);
    const [quickDayType, setQuickDayType] = useState('full_day');
    const [savingQuickEmpId, setSavingQuickEmpId] = useState(null);

    useEffect(() => {
        const handleVoiceAttendanceUpdate = () => {
            load().catch(() => {});
            loadLiveLocations();
        };
        window.addEventListener('solarflow:attendance-updated', handleVoiceAttendanceUpdate);
        return () => window.removeEventListener('solarflow:attendance-updated', handleVoiceAttendanceUpdate);
    }, [date, employeeId]);

    const checklistEmployees = useMemo(() => {
        const activeList = (employees || []).filter(emp => emp.active !== false);
        // Sort so manager_attendance_only or pending attendance appear first
        return [...activeList].sort((a, b) => {
            const aRow = (rows || []).find(r => String(r.employee_id) === String(a.id) || String(r.employee?.id) === String(a.id));
            const bRow = (rows || []).find(r => String(r.employee_id) === String(b.id) || String(r.employee?.id) === String(b.id));
            if (Boolean(a.manager_attendance_only) !== Boolean(b.manager_attendance_only)) {
                return a.manager_attendance_only ? -1 : 1;
            }
            if (Boolean(aRow) !== Boolean(bRow)) {
                return aRow ? 1 : -1;
            }
            return String(a.name || '').localeCompare(String(b.name || ''));
        });
    }, [employees, rows]);

    const confirmQuickAttendance = async (emp, chosenDayType = quickDayType) => {
        if (!emp?.id) return;
        setMessage('');
        setSavingQuickEmpId(emp.id);
        try {
            const targetDate = date > localDate() ? localDate() : date;
            await api('attendance/quick-mark', {
                method: 'POST',
                body: JSON.stringify({
                    employee_id: Number(emp.id),
                    attendance_date: targetDate,
                    day_type: chosenDayType,
                    entry_reason: chosenDayType === 'absent'
                        ? 'Superadmin marked absent (પ્લાન્ટ પર ગેરહાજર)'
                        : (chosenDayType === 'half_day'
                            ? 'Half Day confirmed via Quick Attendance Checklist'
                            : 'Full Day confirmed via Quick Attendance Checklist')
                })
            });
            setQuickSelectEmpId(null);
            setMessage(
                currentLang === 'en'
                    ? `Attendance saved (${chosenDayType === 'absent' ? '❌ Absent (Full day pay cut)' : (chosenDayType === 'half_day' ? '🌗 Half Day (Half day pay cut)' : '☀️ Full Day')}) for ${emp.name}.`
                    : `${emp.name} ની હાજરી (${chosenDayType === 'absent' ? '❌ Absent - ગેરહાજર (પૂરો દિવસ કપાત)' : (chosenDayType === 'half_day' ? '🌗 Half Day - અડધો દિવસ (અડધો દિવસ કપાત)' : '☀️ Full Day - આખો દિવસ')}) સફળતાપૂર્વક સેવ થઈ ગઈ છે.`
            );
            await load();
        } catch (error) {
            setMessage(error.message || 'Could not save attendance.');
        } finally {
            setSavingQuickEmpId(null);
        }
    };

    const absentToday = useMemo(() => {
        if (!isToday || !employees.length) return [];
        return employees.filter(emp => 
            emp.active && 
            !emp.manager_attendance_only && 
            !(rows || []).some(r => String(r.employee_id) === String(emp.id) || String(r.employee?.id) === String(emp.id))
        );
    }, [isToday, employees, rows]);

    const totals = {
        present: (rows || []).filter(row => row.clock_out_at && row.status === 'present').length,
        working_now: (rows || []).filter(row => !row.clock_out_at && (isToday || row.attendance_date === todayDate)).length,
        missing_out: (rows || []).filter(row => !row.clock_out_at && !isToday && row.attendance_date !== todayDate).length,
        late: (rows || []).filter(row => row.is_late).length,
        corrected: (rows || []).filter(row => row.manual_correction).length,
    };

    return <div className="attendance-admin">
        <style>{`
            @keyframes bounceWalk {
                0%, 100% { transform: translateY(0px) rotate(0deg); }
                25% { transform: translateY(-3px) rotate(-6deg); }
                75% { transform: translateY(-3px) rotate(6deg); }
            }
            @keyframes rideBike {
                0%, 100% { transform: translateX(0px) translateY(0px) scale(1); }
                50% { transform: translateX(2px) translateY(-2px) scale(1.08); }
            }
        `}</style>
        <div className="cards attendance-cards">
            <article className="metric">
                <span>{isToday ? (currentLang === 'en' ? 'Completed Shift' : 'પૂર્ણ શિફ્ટ (Completed)') : (currentLang === 'en' ? 'Completed Present' : 'Completed present')}</span>
                <strong>{totals.present}</strong>
                <small>{isToday ? (currentLang === 'en' ? 'Completed today' : 'આજે પૂર્ણ થયેલ') : (currentLang === 'en' ? 'Selected date' : 'selected date')}</small>
            </article>
            <article className={`metric ${isToday ? 'on' : 'amber'}`} style={isToday ? {background: '#ecfdf5', borderColor: '#a7f3d0'} : {}}>
                <span style={isToday ? {color: '#065f46'} : {}}>{isToday ? (currentLang === 'en' ? '🟢 Working Now' : '🟢 ચાલુ શિફ્ટ (Working Now)') : (currentLang === 'en' ? 'Missing Time Out' : 'Missing Time Out')}</span>
                <strong style={isToday ? {color: '#047857'} : {}}>{isToday ? totals.working_now : totals.missing_out}</strong>
                <small style={isToday ? {color: '#059669'} : {}}>{isToday ? (currentLang === 'en' ? 'Currently working on site' : 'હાલ સાઇટ પર કાર્યરત') : (currentLang === 'en' ? 'Needs attention' : 'needs attention')}</small>
            </article>
            <article className="metric">
                <span>Late arrivals</span>
                <strong>{totals.late}</strong>
                <small>after grace period</small>
            </article>
            <article className="metric">
                <span>Manual corrections</span>
                <strong>{totals.corrected}</strong>
                <small>audited records</small>
            </article>
        </div>
        {message && <div className={message.includes('saved') || message.includes('dispatched') || message.includes('delivered') ? 'success' : 'error'}>{message}</div>}

        {/* 📡 Live Employee GPS Field Tracker & Map Box */}
        <section className="panel" style={{marginBottom: '24px', border: '1px solid #cbe4d7', background: 'linear-gradient(to bottom, #ffffff, #f9fdfa)', padding: '16px'}}>
            <div style={{display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '14px'}}>
                <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px'}}>
                    <div>
                        <div style={{display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '8px'}}>
                            <h2 style={{display: 'flex', alignItems: 'center', gap: '8px', margin: 0, fontSize: '16px', fontWeight: 800, color: '#123e30'}}>
                                <Navigation size={18} style={{color: '#22c55e', flexShrink: 0}}/>
                                {currentLang === 'en' ? 'Employee Live Location Tracker' : 'કર્મચારી લાઈવ લોકેશન ટ્રેકર'}
                            </h2>
                            <span className="status on" style={{padding: '3px 8px', fontSize: '11px', fontWeight: 800, whiteSpace: 'nowrap'}}>
                                🟢 {activeLiveCount} Live Online
                            </span>
                        </div>
                        <p style={{margin: '4px 0 0', fontSize: '11.5px', color: '#627c70'}}>
                            {currentLang === 'en' ? 'Real-time GPS tracker when employee app/PWA is active or in background (Syncs every 30s)' : 'એમ્પ્લોયીનો ફોન/PWA ઓપન અથવા મિનિમાઇઝ હોય ત્યારે રીઅલ-ટાઇમ GPS (Syncs every 30s)'}
                        </p>
                    </div>
                    <div style={{display: 'flex', gap: '6px', alignItems: 'center', flexWrap: 'wrap'}}>
                        <div style={{
                            display: 'inline-flex',
                            background: '#e2ece5',
                            padding: '3px',
                            borderRadius: '12px',
                            gap: '3px'
                        }}>
                            <button
                                type="button"
                                onClick={() => setMapMode('satellite')}
                                style={{
                                    border: 0,
                                    borderRadius: '9px',
                                    padding: '6px 12px',
                                    fontSize: '11.5px',
                                    fontWeight: 700,
                                    cursor: 'pointer',
                                    background: mapMode === 'satellite' ? '#2563eb' : 'transparent',
                                    color: mapMode === 'satellite' ? '#ffffff' : '#334155',
                                    boxShadow: mapMode === 'satellite' ? '0 2px 6px rgba(37,99,235,0.3)' : 'none',
                                    transition: 'all 0.15s ease'
                                }}
                                title={currentLang === 'en' ? 'Google Satellite Map' : 'ગૂગલ સેટેલાઇટ મેપ'}
                            >
                                🛰️ Google Satellite
                            </button>
                            <button
                                type="button"
                                onClick={() => setMapMode('roadmap')}
                                style={{
                                    border: 0,
                                    borderRadius: '9px',
                                    padding: '6px 12px',
                                    fontSize: '11.5px',
                                    fontWeight: 700,
                                    cursor: 'pointer',
                                    background: mapMode === 'roadmap' ? '#0f172a' : 'transparent',
                                    color: mapMode === 'roadmap' ? '#ffffff' : '#334155',
                                    boxShadow: mapMode === 'roadmap' ? '0 2px 6px rgba(15,23,42,0.3)' : 'none',
                                    transition: 'all 0.15s ease'
                                }}
                                title={currentLang === 'en' ? 'Standard Roadmap' : 'સામાન્ય રોડમેપ'}
                            >
                                {currentLang === 'en' ? '🗺️ Roadmap' : '🗺️ રોડમેપ'}
                            </button>
                        </div>
                        <button
                            type="button"
                            className="secondary"
                            onClick={loadLiveLocations}
                            disabled={loadingLocations}
                            style={{display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '7px 12px', fontSize: '11.5px', borderRadius: '10px', fontWeight: 600}}
                            title="Refresh Live GPS coordinates"
                        >
                            <RefreshCw size={13} className={loadingLocations ? 'spin' : ''}/> {currentLang === 'en' ? 'Refresh' : 'રીફ્રેશ'}
                        </button>
                    </div>
                </div>
            </div>

            {displayLocations.length > 0 ? (
                <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
                    gap: '14px',
                    marginTop: '12px'
                }}>
                    {displayLocations.map(emp => (
                        <div
                            key={emp.employee_id}
                            style={{
                                background: '#ffffff',
                                border: emp.is_live ? '1.5px solid #86efac' : '1px solid #e2ece5',
                                borderRadius: '14px',
                                padding: '14px 16px',
                                boxShadow: emp.is_live ? '0 4px 14px rgba(34, 197, 94, 0.12)' : '0 2px 6px rgba(0,0,0,0.03)',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '10px'
                            }}
                        >
                            <div style={{display: 'flex', alignItems: 'center', gap: '12px'}}>
                                <div style={{
                                    width: '42px',
                                    height: '42px',
                                    borderRadius: '12px',
                                    background: emp.is_live ? '#dcfce7' : '#f1f5f9',
                                    color: emp.is_live ? '#15803d' : '#64748b',
                                    display: 'grid',
                                    placeItems: 'center',
                                    fontWeight: 800,
                                    fontSize: '14px',
                                    overflow: 'hidden',
                                    flexShrink: 0
                                }}>
                                    {emp.avatar_url ? (
                                        <img src={emp.avatar_url} alt={emp.name} style={{width: '100%', height: '100%', objectFit: 'cover'}}/>
                                    ) : (
                                        <span>{emp.name.slice(0, 2).toUpperCase()}</span>
                                    )}
                                </div>
                                <div style={{flex: 1, minWidth: 0}}>
                                    <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '6px'}}>
                                        <b style={{fontSize: '13px', color: '#133e31', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>
                                            {emp.name}
                                        </b>
                                        {emp.is_live ? (
                                            <span className="status on" style={{fontSize: '10px', padding: '2px 7px'}}>
                                                🟢 Live ({emp.last_seen})
                                            </span>
                                        ) : emp.latitude ? (
                                            <span className="status warning" style={{fontSize: '10px', padding: '2px 7px'}}>
                                                🟡 {emp.last_seen}
                                            </span>
                                        ) : (
                                            <span className="status" style={{fontSize: '10px', padding: '2px 7px'}}>
                                                ⚪ Offline
                                            </span>
                                        )}
                                    </div>
                                    <small style={{display: 'block', color: '#687e74', fontSize: '11px', marginTop: '2px'}}>
                                        {emp.employee_code} · {emp.designation} · <span style={{color: '#0d9488'}}>{emp.company_name}</span>
                                    </small>
                                </div>
                            </div>

                            {/* 🌴/⚠️ Leave & Absence Notice (Past 11:00 AM or Leave Applied) */}
                            {emp.leave_info && emp.leave_info.has_leave && (
                                <div style={{
                                    background: emp.leave_info.is_approved ? '#ecfdf5' : '#fffbeb',
                                    border: emp.leave_info.is_approved ? '1.5px solid #86efac' : '1.5px solid #fde68a',
                                    borderRadius: '10px',
                                    padding: '8px 12px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    fontSize: '11.5px',
                                    color: emp.leave_info.is_approved ? '#065f46' : '#92400e',
                                    fontWeight: 700
                                }}>
                                    <span style={{fontSize: '15px'}}>{emp.leave_info.is_approved ? '🌴' : '⚠️'}</span>
                                    <div style={{flex: 1}}>
                                        <div>{emp.leave_info.message}</div>
                                        <small style={{display: 'block', fontSize: '10px', opacity: 0.85, marginTop: '2px'}}>
                                            {emp.leave_info.is_approved ? (currentLang === 'en' ? 'Approved Leave' : 'રજા મંજૂર થયેલ છે (Approved Leave)') : (currentLang === 'en' ? 'Unapproved Leave / Absent' : 'રજા અપ્રૂવલ લીધી નહોતી / ગેરહાજર')}
                                        </small>
                                    </div>
                                    <span style={{
                                        fontSize: '9.5px',
                                        padding: '2px 6px',
                                        borderRadius: '4px',
                                        background: emp.leave_info.is_approved ? '#10b981' : '#f59e0b',
                                        color: '#fff',
                                        fontWeight: 800,
                                        whiteSpace: 'nowrap'
                                    }}>
                                        {emp.leave_info.badge}
                                    </span>
                                </div>
                            )}

                            {/* 🏍️ Movement / Activity Status Badge */}
                            <div style={{
                                background: emp.movement === 'bike' ? '#fef3c7' : emp.movement === 'walking' ? '#e0f2fe' : '#f8faf9',
                                borderRadius: '10px',
                                padding: '8px 12px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                                fontSize: '11px',
                                border: emp.movement === 'bike' ? '1px solid #fde68a' : emp.movement === 'walking' ? '1px solid #bae6fd' : '1px solid #e2ece5'
                            }}>
                                <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
                                    <span style={{
                                        fontSize: '18px',
                                        display: 'inline-block',
                                        animation: emp.movement === 'bike' ? 'rideBike 0.8s ease-in-out infinite' : emp.movement === 'walking' ? 'bounceWalk 0.7s ease-in-out infinite' : 'none'
                                    }}>
                                        {emp.movement_icon || (emp.movement === 'bike' ? '🏍️' : emp.movement === 'walking' ? '🚶‍♂️' : '🧍‍♂️')}
                                    </span>
                                    <div>
                                        <b style={{color: emp.movement === 'bike' ? '#b45309' : emp.movement === 'walking' ? '#0369a1' : '#1e293b'}}>
                                            {emp.movement_label || (emp.movement === 'bike' ? (currentLang === 'en' ? 'Moving on bike' : 'બાઇક પર ગતિમાં') : emp.movement === 'walking' ? (currentLang === 'en' ? 'Walking' : 'પગપાળા ચાલે છે') : (currentLang === 'en' ? 'Stationary (On site)' : 'સ્થિર છે (સાઇટ પર)'))}
                                        </b>
                                        {emp.speed ? (
                                            <small style={{display: 'block', color: '#64748b', fontSize: '10px'}}>
                                                {currentLang === 'en' ? 'Speed: ' : 'ઝડપ: '}{Math.round(emp.speed)} km/h
                                            </small>
                                        ) : null}
                                    </div>
                                </div>
                                <div style={{display: 'flex', alignItems: 'center', gap: '6px'}}>
                                    {emp.speed ? (
                                        <span style={{fontWeight: 800, fontSize: '10.5px', color: '#0f766e', background: '#ccfbf1', padding: '3px 8px', borderRadius: '6px'}}>
                                            ⚡ {Math.round(emp.speed)} km/h
                                        </span>
                                    ) : null}
                                    <span style={{color: emp.status === 'Working' ? '#16a34a' : emp.status === 'Shift Ended' ? '#0284c7' : '#eab308', fontWeight: 700}}>
                                        {emp.status}
                                    </span>
                                </div>
                            </div>

                            {emp.is_live && emp.latitude && emp.longitude ? (
                                <div style={{display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '2px'}}>
                                    {/* 🗺️ Default Embedded Small Interactive Map */}
                                    <div style={{
                                        position: 'relative',
                                        width: '100%',
                                        height: '220px',
                                        borderRadius: '12px',
                                        overflow: 'hidden',
                                        border: '1px solid #cbd5e1',
                                        background: '#f1f5f9',
                                        boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.06)',
                                        touchAction: 'auto'
                                    }}>
                                        <iframe
                                            title={`Live Map for ${emp.name}`}
                                            width="100%"
                                            height="100%"
                                            frameBorder="0"
                                            allowFullScreen
                                            src={`https://maps.google.com/maps?q=${emp.latitude},${emp.longitude}${mapMode === 'roadmap' ? '' : '&t=k'}&hl=gu&z=${zoomLevel}&output=embed`}
                                            style={{border: 0, width: '100%', height: '100%', touchAction: 'auto'}}
                                            loading="lazy"
                                        />

                                        {/* 🚶 Animated Movement Floating Pin on Map Center */}
                                        <div style={{
                                            position: 'absolute',
                                            top: '12px',
                                            left: '12px',
                                            background: emp.movement === 'bike' ? 'rgba(245, 158, 11, 0.95)' : emp.movement === 'walking' ? 'rgba(2, 132, 199, 0.95)' : 'rgba(22, 163, 74, 0.95)',
                                            color: '#ffffff',
                                            padding: '4px 10px',
                                            borderRadius: '20px',
                                            fontSize: '11px',
                                            fontWeight: 800,
                                            boxShadow: '0 3px 10px rgba(0,0,0,0.3)',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '6px',
                                            zIndex: 4
                                        }}>
                                            <span style={{
                                                fontSize: '15px',
                                                display: 'inline-block',
                                                animation: emp.movement === 'bike' ? 'rideBike 0.8s ease-in-out infinite' : emp.movement === 'walking' ? 'bounceWalk 0.7s ease-in-out infinite' : 'none'
                                            }}>
                                                {emp.movement_icon || (emp.movement === 'bike' ? '🏍️' : emp.movement === 'walking' ? '🚶‍♂️' : '🧍‍♂️')}
                                            </span>
                                            <span>
                                                {emp.movement === 'bike' ? `Bike: ${Math.round(emp.speed || 0)} km/h` : emp.movement === 'walking' ? `Walking: ${Math.round(emp.speed || 4)} km/h` : (currentLang === 'en' ? 'Stationary (0 km/h)' : 'સ્થિર છે (0 km/h)')}
                                            </span>
                                        </div>

                                        {/* 🔍 Touch-friendly Large Zoom Controls on Map */}
                                        <div style={{
                                            position: 'absolute',
                                            top: '8px',
                                            right: '8px',
                                            display: 'flex',
                                            flexDirection: 'column',
                                            gap: '5px',
                                            zIndex: 5
                                        }}>
                                            <button
                                                type="button"
                                                onClick={() => setZoomLevel(z => Math.min(21, z + 1))}
                                                style={{
                                                    width: '34px',
                                                    height: '34px',
                                                    borderRadius: '8px',
                                                    background: 'rgba(255,255,255,0.95)',
                                                    border: '1px solid #cbd5e1',
                                                    color: '#0f172a',
                                                    fontWeight: 900,
                                                    fontSize: '18px',
                                                    display: 'grid',
                                                    placeItems: 'center',
                                                    cursor: 'pointer',
                                                    padding: 0,
                                                    boxShadow: '0 2px 6px rgba(0,0,0,0.25)'
                                                }}
                                                title={currentLang === 'en' ? 'Zoom In' : 'Zoom In (નજીક લાવો)'}
                                            >
                                                +
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => setZoomLevel(z => Math.max(14, z - 1))}
                                                style={{
                                                    width: '34px',
                                                    height: '34px',
                                                    borderRadius: '8px',
                                                    background: 'rgba(255,255,255,0.95)',
                                                    border: '1px solid #cbd5e1',
                                                    color: '#0f172a',
                                                    fontWeight: 900,
                                                    fontSize: '18px',
                                                    display: 'grid',
                                                    placeItems: 'center',
                                                    cursor: 'pointer',
                                                    padding: 0,
                                                    boxShadow: '0 2px 6px rgba(0,0,0,0.25)'
                                                }}
                                                title={currentLang === 'en' ? 'Zoom Out' : 'Zoom Out (દૂર કરો)'}
                                            >
                                                -
                                            </button>
                                        </div>

                                        {/* 📍 Bottom Map Status Tag */}
                                        <div style={{
                                            position: 'absolute',
                                            bottom: '6px',
                                            left: '8px',
                                            background: 'rgba(15, 23, 42, 0.88)',
                                            color: '#ffffff',
                                            padding: '3px 8px',
                                            borderRadius: '6px',
                                            fontSize: '10px',
                                            pointerEvents: 'none',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '5px'
                                        }}>
                                            <span>{emp.movement_icon || '📍'}</span>
                                            <b style={{color: '#38bdf8'}}>
                                                {mapMode === 'satellite' ? 'Google Satellite' : 'Roadmap'}
                                            </b>
                                            <span>· Zoom: {zoomLevel}x</span>
                                        </div>
                                    </div>

                                    {/* 🔘 Mobile Quick Zoom Presets */}
                                    <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '6px'}}>
                                        <span style={{fontSize: '11px', color: '#64748b', fontWeight: 600}}>{currentLang === 'en' ? 'Zoom Level:' : 'ઝૂમ લેવલ:'}</span>
                                        <div style={{display: 'flex', gap: '4px'}}>
                                            <button
                                                type="button"
                                                onClick={() => setZoomLevel(21)}
                                                style={{
                                                    padding: '4px 8px',
                                                    fontSize: '10px',
                                                    borderRadius: '6px',
                                                    fontWeight: zoomLevel === 21 ? 800 : 600,
                                                    background: zoomLevel === 21 ? '#0284c7' : '#f1f5f9',
                                                    color: zoomLevel === 21 ? '#ffffff' : '#334155',
                                                    border: zoomLevel === 21 ? '1px solid #0284c7' : '1px solid #cbd5e1',
                                                    cursor: 'pointer'
                                                }}
                                            >
                                                {currentLang === 'en' ? '🔍 21x (Ultra Close)' : '🔍 21x (અલ્ટ્રા નજીક)'}
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => setZoomLevel(19)}
                                                style={{
                                                    padding: '4px 8px',
                                                    fontSize: '10px',
                                                    borderRadius: '6px',
                                                    fontWeight: zoomLevel === 19 ? 800 : 600,
                                                    background: zoomLevel === 19 ? '#0284c7' : '#f1f5f9',
                                                    color: zoomLevel === 19 ? '#ffffff' : '#334155',
                                                    border: zoomLevel === 19 ? '1px solid #0284c7' : '1px solid #cbd5e1',
                                                    cursor: 'pointer'
                                                }}
                                            >
                                                {currentLang === 'en' ? '🏠 19x (Close)' : '🏠 19x (નજીક)'}
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => setZoomLevel(16)}
                                                style={{
                                                    padding: '4px 8px',
                                                    fontSize: '10px',
                                                    borderRadius: '6px',
                                                    fontWeight: zoomLevel === 16 ? 800 : 600,
                                                    background: zoomLevel === 16 ? '#0284c7' : '#f1f5f9',
                                                    color: zoomLevel === 16 ? '#ffffff' : '#334155',
                                                    border: zoomLevel === 16 ? '1px solid #0284c7' : '1px solid #cbd5e1',
                                                    cursor: 'pointer'
                                                }}
                                            >
                                                {currentLang === 'en' ? '🗺️ 16x (Area)' : '🗺️ 16x (એરિયા)'}
                                            </button>
                                        </div>
                                    </div>

                                    <div style={{display: 'flex', gap: '8px', flexWrap: 'wrap'}}>
                                        <button
                                            type="button"
                                            className="secondary"
                                            onClick={() => setSelectedMapEmployee(emp)}
                                            style={{
                                                flex: 1,
                                                minWidth: '130px',
                                                padding: '7px 10px',
                                                fontSize: '11.5px',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                gap: '5px',
                                                borderRadius: '8px'
                                            }}
                                        >
                                            <MapPin size={13}/> {currentLang === 'en' ? 'View Full Map' : 'મોટો મેપ જુઓ'}
                                        </button>
                                        <a
                                            href={emp.map_url}
                                            target="_blank"
                                            rel="noreferrer"
                                            className="primary"
                                            style={{
                                                flex: 1,
                                                minWidth: '130px',
                                                padding: '7px 10px',
                                                fontSize: '11.5px',
                                                textDecoration: 'none',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                gap: '5px',
                                                borderRadius: '8px'
                                            }}
                                            title="Open in Google Maps App"
                                        >
                                            <ExternalLink size={13}/> {currentLang === 'en' ? 'Open in Maps App' : 'Maps App માં જુઓ'}
                                        </a>
                                    </div>
                                </div>
                            ) : (
                                <div style={{
                                    fontSize: '11.5px',
                                    color: '#64748b',
                                    background: '#f8fafc',
                                    borderRadius: '10px',
                                    padding: '14px 16px',
                                    textAlign: 'center',
                                    border: '1px dashed #cbd5e1',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    gap: '4px'
                                }}>
                                    <span style={{fontSize: '16px'}}>⚪</span>
                                    <b style={{color: '#475569'}}>
                                        {emp.leave_info && emp.leave_info.has_leave
                                            ? (emp.leave_info.is_approved ? (currentLang === 'en' ? '🌴 Approved Leave Today' : '🌴 આજે રજા મંજૂર થયેલ છે') : (currentLang === 'en' ? '⚠️ Unapproved Leave' : '⚠️ રજા અપ્રૂવલ લીધી નહોતી'))
                                            : (currentLang === 'en' ? 'Employee currently offline' : 'કર્મચારી હાલમાં ઑફલાઇન છે')}
                                    </b>
                                    <span style={{fontSize: '10.5px', color: '#94a3b8'}}>
                                        {emp.leave_info && emp.leave_info.has_leave
                                            ? emp.leave_info.message
                                            : (currentLang === 'en' ? 'Live GPS location map will appear here once employee opens app.' : 'જ્યારે કર્મચારી એપ ઓપન કરશે ત્યારે જ તેમનો લાઈવ લોકેશન મેપ અહીં દેખાશે.')}
                                    </span>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            ) : (
                <div style={{textAlign: 'center', padding: '20px', color: '#64748b', fontSize: '13px'}}>
                    {currentLang === 'en' ? 'No employees currently active for live tracking.' : 'હાલ કોઈ કર્મચારી લાઈવ ટ્રેકિંગ માટે ઉપલબ્ધ નથી.'}
                </div>
            )}
        </section>

        <section className="panel">
            <div className="panel-head attendance-list-head">
                <div>
                    <h2>{currentLang === 'en' ? 'Daily Attendance' : 'દૈનિક હાજરી (Daily Attendance)'}</h2>
                    <p>{currentLang === 'en' ? 'Employee and audited manager-entered records.' : 'કર્મચારી અને ઓડિટેડ હાજરી રેકોર્ડ્સ.'}</p>
                </div>
                <div style={{display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap'}}>
                    <div className="attendance-view-toggle">
                        <button
                            type="button"
                            className={viewMode === 'cards' ? 'active' : ''}
                            onClick={() => setViewMode('cards')}
                            title="Cards View"
                        >
                            🗂️ {currentLang === 'en' ? 'Cards' : 'કાર્ડ્સ'}
                        </button>
                        <button
                            type="button"
                            className={viewMode === 'table' ? 'active' : ''}
                            onClick={() => setViewMode('table')}
                            title="Table View"
                        >
                            📑 {currentLang === 'en' ? 'Table' : 'ટેબલ'}
                        </button>
                    </div>
                    {canRecord && (
                        <button type="button" className="primary" onClick={openManual}>
                            <Plus size={16}/> {currentLang === 'en' ? 'Add attendance' : 'હાજરી ઉમેરો'}
                        </button>
                    )}
                </div>
            </div>

            {/* 🌴 Leaves and Absences Today Overview */}
            {isToday && absentToday.length > 0 && (
                <div style={{
                    margin: '0 0 16px 0',
                    padding: '12px 14px',
                    background: '#f8fafc',
                    border: '1px solid #e2e8f0',
                    borderRadius: '12px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px'
                }}>
                    <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px'}}>
                        <b style={{fontSize: '12.5px', color: '#1e293b', display: 'flex', alignItems: 'center', gap: '6px'}}>
                            {currentLang === 'en' ? '🌴 Employees On Leave / Not Present Today' : '🌴 આજે રજા પર / હાજર ન થયેલા કર્મચારીઓ'} ({absentToday.length})
                        </b>
                        <span style={{fontSize: '10.5px', color: '#64748b', fontWeight: 600}}>{currentLang === 'en' ? 'Today Status (11:00 AM)' : 'આજની સ્થિતિ (૧૧:૦૦ AM)'}</span>
                    </div>
                    <div style={{display: 'flex', flexDirection: 'column', gap: '6px'}}>
                        {absentToday.map(abs => {
                            const liveEmp = displayLocations.find(l => String(l.employee_id) === String(abs.id));
                            const leaveInfo = liveEmp?.leave_info || (abs.today_leave ? {
                                has_leave: true,
                                is_approved: abs.today_leave.is_approved,
                                message: abs.today_leave.is_approved
                                    ? (currentLang === 'en' ? `${abs.name} is on approved leave today (${abs.today_leave.leave_type})` : `${abs.name} આજે રજા પર છે (આજે રજા મંજૂર થયેલ છે - ${abs.today_leave.leave_type})`)
                                    : (currentLang === 'en' ? `${abs.name} is absent (Unapproved leave)` : `${abs.name} રજા પર છે (રજા અપ્રૂવલ લીધી નહોતી)`)
                            } : {
                                has_leave: new Date().getHours() >= 11,
                                is_approved: false,
                                message: (currentLang === 'en' ? `${abs.name} not present by 11:00 AM (Unapproved leave - absent)` : `${abs.name} આજે ૧૧:૦૦ વાગ્યા સુધી હાજર થયા નથી (રજા અપ્રૂવલ લીધી નહોતી - રજા પર છે)`)
                            });
                            return (
                                <div key={abs.id} style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    padding: '7px 12px',
                                    borderRadius: '8px',
                                    background: leaveInfo?.is_approved ? '#ecfdf5' : '#fffbeb',
                                    border: leaveInfo?.is_approved ? '1px solid #a7f3d0' : '1px solid #fde68a',
                                    fontSize: '11.5px',
                                    color: leaveInfo?.is_approved ? '#065f46' : '#92400e',
                                    fontWeight: 600,
                                    flexWrap: 'wrap',
                                    gap: '6px'
                                }}>
                                    <div style={{display: 'flex', alignItems: 'center', gap: '6px'}}>
                                        <span>{leaveInfo?.is_approved ? '🌴' : '⚠️'}</span>
                                        <b>{abs.name} ({abs.employee_code}):</b>
                                        <span>{leaveInfo?.message}</span>
                                    </div>
                                    <span style={{
                                        fontSize: '10px',
                                        padding: '2px 8px',
                                        borderRadius: '4px',
                                        fontWeight: 800,
                                        background: leaveInfo?.is_approved ? '#10b981' : '#f59e0b',
                                        color: '#fff'
                                    }}>
                                        {leaveInfo?.is_approved ? (currentLang === 'en' ? 'Approved' : 'મંજૂર રજા') : (currentLang === 'en' ? 'Unapproved' : 'મંજૂરી વિના')}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* 🌴 Employee Leaves Management (All, Pending, Approved, Rejected) */}
            {allLeaves.length > 0 && (
                <div style={{
                    margin: '0 0 16px 0',
                    padding: '14px 16px',
                    background: '#ffffff',
                    border: '1.5px solid #e2e8f0',
                    borderRadius: '14px',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '12px'
                }}>
                    <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '8px'}}>
                        <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
                            <span style={{fontSize: '20px'}}>🌴</span>
                            <div>
                                <b style={{fontSize: '14px', color: '#0f172a'}}>
                                    {currentLang === 'en' ? 'Employee Leaves Records' : 'કર્મચારીઓની રજાઓ (Employee Leaves)'}
                                </b>
                                <span style={{display: 'block', fontSize: '11.5px', color: '#64748b'}}>
                                    {currentLang === 'en'
                                        ? `${activeLeaves.length} active/upcoming · ${pastLeaves.length} past records`
                                        : `${activeLeaves.length} ચાલુ/નવી રજાઓ · ${pastLeaves.length} જૂનો ઇતિહાસ`}
                                </span>
                            </div>
                        </div>

                        {/* Filter Tabs: Active (Today/Tomorrow/Pending), Pending, Approved, History (Past), All */}
                        <div style={{display: 'flex', gap: '4px', background: '#f1f5f9', padding: '3px', borderRadius: '8px', flexWrap: 'wrap'}}>
                            {[
                                { key: 'active', label: currentLang === 'en' ? 'Today & Upcoming' : 'ચાલુ / નવી', count: activeLeaves.length, color: '#059669' },
                                { key: 'pending', label: currentLang === 'en' ? 'Pending' : 'પેન્ડિંગ', count: allLeaves.filter(l => l.status === 'pending').length, color: '#d97706' },
                                { key: 'approved', label: currentLang === 'en' ? 'Approved (Active)' : 'મંજૂર', count: activeLeaves.filter(l => l.status === 'approved').length, color: '#16a34a' },
                                { key: 'history', label: currentLang === 'en' ? 'Past Records' : 'જૂનો ઇતિહાસ', count: pastLeaves.length, color: '#64748b' },
                                { key: 'all', label: currentLang === 'en' ? 'All' : 'બધી', count: allLeaves.length, color: '#0f172a' },
                            ].map(tab => (
                                <button
                                    key={tab.key}
                                    type="button"
                                    onClick={() => setLeaveFilter(tab.key)}
                                    style={{
                                        border: 'none',
                                        background: leaveFilter === tab.key ? '#ffffff' : 'transparent',
                                        color: leaveFilter === tab.key ? (tab.color || '#0f172a') : '#64748b',
                                        fontWeight: leaveFilter === tab.key ? 700 : 500,
                                        fontSize: '12px',
                                        padding: '4px 10px',
                                        borderRadius: '6px',
                                        boxShadow: leaveFilter === tab.key ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
                                        cursor: 'pointer',
                                        display: 'inline-flex',
                                        alignItems: 'center',
                                        gap: '5px'
                                    }}
                                >
                                    <span>{tab.label}</span>
                                    <span style={{
                                        background: leaveFilter === tab.key ? '#f1f5f9' : '#e2e8f0',
                                        padding: '1px 5px',
                                        borderRadius: '999px',
                                        fontSize: '10.5px'
                                    }}>
                                        {tab.count}
                                    </span>
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Filtered Leaves Grid */}
                    {(() => {
                        const filtered = (() => {
                            if (leaveFilter === 'active') return activeLeaves;
                            if (leaveFilter === 'pending') return allLeaves.filter(l => l.status === 'pending');
                            if (leaveFilter === 'approved') return activeLeaves.filter(l => l.status === 'approved');
                            if (leaveFilter === 'history') return pastLeaves;
                            if (leaveFilter === 'all') return allLeaves;
                            return activeLeaves;
                        })();

                        if (filtered.length === 0) {
                            if (leaveFilter === 'active') {
                                return (
                                    <div style={{
                                        textAlign: 'center',
                                        padding: '16px 20px',
                                        color: '#64748b',
                                        fontSize: '12.5px',
                                        background: '#f8fafc',
                                        borderRadius: '10px',
                                        border: '1px dashed #cbd5e1',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        flexWrap: 'wrap',
                                        gap: '10px'
                                    }}>
                                        <span>🌴 {currentLang === 'en' ? 'No pending or active leaves for today or tomorrow (All staff on duty).' : 'આજે કે આવતીકાલ માટે કોઈ પેન્ડિંગ કે નવી રજા નથી (બધા કર્મચારીઓ હાજર).'}</span>
                                        {pastLeaves.length > 0 && (
                                            <button
                                                type="button"
                                                onClick={() => setLeaveFilter('history')}
                                                style={{
                                                    border: 'none',
                                                    background: '#e2e8f0',
                                                    color: '#1e293b',
                                                    padding: '5px 12px',
                                                    borderRadius: '6px',
                                                    fontSize: '11.5px',
                                                    fontWeight: 600,
                                                    cursor: 'pointer'
                                                }}
                                            >
                                                {currentLang === 'en' ? `View Past Records (${pastLeaves.length})` : `જૂનો ઇતિહાસ જુઓ (${pastLeaves.length})`}
                                            </button>
                                        )}
                                    </div>
                                );
                            }
                            return (
                                <div style={{textAlign: 'center', padding: '20px', color: '#94a3b8', fontSize: '12.5px'}}>
                                    {currentLang === 'en' ? 'No leaves found for this filter.' : 'આ ફિલ્ટરમાં કોઈ રજા મળી નથી.'}
                                </div>
                            );
                        }
                        return (
                            <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(290px, 1fr))', gap: '10px'}}>
                                {filtered.map(leave => {
                                    const isPending = leave.status === 'pending';
                                    const isApproved = leave.status === 'approved';
                                    const isRejected = leave.status === 'rejected';

                                    return (
                                        <div key={leave.id} style={{
                                            background: isPending ? '#fffbeb' : isApproved ? '#f0fdf4' : '#fef2f2',
                                            border: isPending ? '1.5px solid #fde68a' : isApproved ? '1px solid #bbf7d0' : '1px solid #fecaca',
                                            borderRadius: '10px',
                                            padding: '10px 12px',
                                            display: 'flex',
                                            flexDirection: 'column',
                                            gap: '6px'
                                        }}>
                                            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
                                                <b style={{fontSize: '13px', color: '#0f172a'}}>
                                                    {leave.employee?.user?.name || leave.employee?.name || 'Employee'}
                                                </b>
                                                <div style={{display: 'flex', gap: '4px', alignItems: 'center'}}>
                                                    <span style={{
                                                        fontSize: '10px',
                                                        background: '#e0f2fe',
                                                        color: '#0369a1',
                                                        padding: '2px 6px',
                                                        borderRadius: '4px',
                                                        fontWeight: 700
                                                    }}>
                                                        {leave.day_part?.replace('_', ' ') || 'Full Day'}
                                                    </span>
                                                    <span style={{
                                                        fontSize: '10px',
                                                        background: isPending ? '#fef3c7' : isApproved ? '#dcfce7' : '#fee2e2',
                                                        color: isPending ? '#b45309' : isApproved ? '#15803d' : '#b91c1c',
                                                        padding: '2px 6px',
                                                        borderRadius: '4px',
                                                        fontWeight: 800
                                                    }}>
                                                        {isPending ? (currentLang === 'en' ? '⏳ Pending' : '⏳ પેન્ડિંગ') : isApproved ? (currentLang === 'en' ? '✓ Approved' : '✓ મંજૂર') : (currentLang === 'en' ? '✕ Rejected' : '✕ નામંજૂર')}
                                                    </span>
                                                </div>
                                            </div>

                                            <div style={{fontSize: '11.5px', color: '#475569', display: 'flex', justifyContent: 'space-between'}}>
                                                <span>📅 <b>{leave.date_from}</b> {leave.date_from !== leave.date_to ? ` થી ${leave.date_to}` : ''}</span>
                                                {leave.leave_type?.name && (
                                                    <span style={{color: '#64748b'}}>({leave.leave_type.name})</span>
                                                )}
                                            </div>

                                            {leave.reason && (
                                                <div style={{fontSize: '11.5px', color: '#334155', fontStyle: 'italic', background: 'rgba(255,255,255,0.7)', padding: '5px 8px', borderRadius: '4px', border: '1px solid rgba(0,0,0,0.05)'}}>
                                                    "{leave.reason}"
                                                </div>
                                            )}

                                            {leave.review_remarks && (
                                                <div style={{fontSize: '11px', color: isApproved ? '#166534' : '#991b1b', background: 'rgba(255,255,255,0.6)', padding: '4px 6px', borderRadius: '4px'}}>
                                                    <b>{currentLang === 'en' ? 'Admin note: ' : 'એડમિન નોંધ: '}</b>{leave.review_remarks}
                                                    {leave.reviewer?.name && ` (${leave.reviewer.name})`}
                                                </div>
                                            )}

                                            {isPending && (
                                                <div style={{display: 'flex', gap: '6px', marginTop: '4px'}}>
                                                    <button
                                                        type="button"
                                                        disabled={reviewingLeaveId === leave.id}
                                                        onClick={() => handleReviewLeave(leave, 'approved')}
                                                        style={{
                                                            flex: 1,
                                                            padding: '6px 10px',
                                                            borderRadius: '6px',
                                                            border: 'none',
                                                            background: '#16a34a',
                                                            color: '#ffffff',
                                                            fontSize: '11.5px',
                                                            fontWeight: 700,
                                                            cursor: 'pointer',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center',
                                                            gap: '4px'
                                                        }}
                                                    >
                                                        ✓ {currentLang === 'en' ? 'Approve' : 'મંજૂર કરો'}
                                                    </button>
                                                    <button
                                                        type="button"
                                                        disabled={reviewingLeaveId === leave.id}
                                                        onClick={() => handleReviewLeave(leave, 'rejected')}
                                                        style={{
                                                            flex: 1,
                                                            padding: '6px 10px',
                                                            borderRadius: '6px',
                                                            border: '1px solid #ef4444',
                                                            background: '#fef2f2',
                                                            color: '#b91c1c',
                                                            fontSize: '11.5px',
                                                            fontWeight: 700,
                                                            cursor: 'pointer',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center',
                                                            gap: '4px'
                                                        }}
                                                    >
                                                        ✕ {currentLang === 'en' ? 'Reject' : 'નામંજૂર'}
                                                    </button>
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        );
                    })()}
                </div>
            )}

            {/* ✅/⬜ Quick Manual Attendance Checklist UI (Full Day / Half Day / Absent Confirm) */}
            {(canRecord || canCorrect) && checklistEmployees.length > 0 && (
                <div style={{
                    margin: '0 0 18px 0',
                    padding: '14px 16px',
                    background: 'linear-gradient(135deg, #f8fafc 0%, #f0fdf4 100%)',
                    border: '1.5px solid #bbf7d0',
                    borderRadius: '14px',
                    boxShadow: '0 4px 12px rgba(16, 185, 129, 0.06)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '10px'
                }}>
                    <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '8px'}}>
                        <div>
                            <b style={{fontSize: '13.5px', color: '#065f46', display: 'flex', alignItems: 'center', gap: '6px'}}>
                                ☑️ {currentLang === 'en' ? 'Quick Attendance Checklist (Full Day / Half Day / Absent)' : 'ઝડપી હાજરી ચેકલિસ્ટ (Full Day / Half Day / ગેરહાજર)'}
                            </b>
                            <small style={{display: 'block', fontSize: '11px', color: '#475569', marginTop: '2px'}}>
                                {currentLang === 'en'
                                    ? `Date: ${date} • (✅) = Full Day • (🌗) = Half Day • (❌) = Absent (Click box to select status & confirm)`
                                    : `તારીખ: ${date} • (✅) = Full Day • (🌗) = Half Day • (❌) = ગેરહાજર (બોક્સ પર ક્લિક કરી Full Day, Half Day અથવા Absent કન્ફર્મ કરો)`}
                            </small>
                        </div>
                        <span style={{
                            fontSize: '11px',
                            fontWeight: 800,
                            padding: '4px 10px',
                            borderRadius: '999px',
                            background: '#dcfce7',
                            color: '#166534',
                            border: '1px solid #86efac'
                        }}>
                            ✅ {checklistEmployees.filter(emp => (rows || []).some(r => String(r.employee_id) === String(emp.id) || String(r.employee?.id) === String(emp.id))).length} / {checklistEmployees.length} {currentLang === 'en' ? 'Completed' : 'પૂર્ણ'}
                        </span>
                    </div>

                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fill, minmax(290px, 1fr))',
                        gap: '10px'
                    }}>
                        {checklistEmployees.map(emp => {
                            const attRow = (rows || []).find(r => String(r.employee_id) === String(emp.id) || String(r.employee?.id) === String(emp.id));
                            const isAbsent = attRow?.status === 'absent';
                            const isHalfDay = !isAbsent && (attRow?.status === 'half_day' || (attRow?.clock_out_at && Number(attRow?.work_minutes || 0) > 0 && Number(attRow?.work_minutes || 0) <= 270));
                            const isCompleted = Boolean(attRow);
                            const isSelectedForConfirm = String(quickSelectEmpId) === String(emp.id);
                            const isSavingThis = String(savingQuickEmpId) === String(emp.id);
                            const empPendingLeave = pendingLeaves.find(l => String(l.employee_id) === String(emp.id));

                            return (
                                <div
                                    key={emp.id}
                                    style={{
                                        background: isAbsent ? '#fff5f5' : (isCompleted ? '#ffffff' : (isSelectedForConfirm ? '#fffbeb' : '#ffffff')),
                                        border: isAbsent
                                            ? '1.5px solid #f87171'
                                            : (isCompleted
                                                ? '1.5px solid #4ade80'
                                                : (isSelectedForConfirm ? '1.5px solid #f59e0b' : '1.5px dashed #cbd5e1')),
                                        borderRadius: '12px',
                                        padding: '10px 12px',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        gap: '8px',
                                        transition: 'all 0.15s ease'
                                    }}
                                >
                                    <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px'}}>
                                        <label
                                            onClick={() => {
                                                if (isSelectedForConfirm) {
                                                    setQuickSelectEmpId(null);
                                                } else {
                                                    setQuickSelectEmpId(emp.id);
                                                    setQuickDayType(isAbsent ? 'absent' : (isHalfDay ? 'half_day' : 'full_day'));
                                                }
                                            }}
                                            style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '10px',
                                                cursor: 'pointer',
                                                flex: 1,
                                                minWidth: 0,
                                                margin: 0
                                            }}
                                        >
                                            {/* Custom Visual Checkbox: Red X if absent, Green Checkmark if completed, Empty Box if pending */}
                                            <div
                                                role="checkbox"
                                                aria-checked={isCompleted}
                                                title={isAbsent ? 'ગેરહાજર નોંધાયેલ છે (Click to edit)' : (isCompleted ? 'હાજરી પૂર્ણ છે (Click to edit)' : 'હાજરી બાકી છે (Click to mark)')}
                                                style={{
                                                    width: '24px',
                                                    height: '24px',
                                                    borderRadius: '7px',
                                                    border: isAbsent
                                                        ? '2px solid #dc2626'
                                                        : (isCompleted
                                                            ? '2px solid #16a34a'
                                                            : (isSelectedForConfirm ? '2px solid #f59e0b' : '2px solid #94a3b8')),
                                                    background: isAbsent
                                                        ? '#dc2626'
                                                        : (isCompleted
                                                            ? '#16a34a'
                                                            : (isSelectedForConfirm ? '#fef3c7' : '#f8fafc')),
                                                    color: isAbsent || isCompleted ? '#ffffff' : '#0f172a',
                                                    display: 'grid',
                                                    placeItems: 'center',
                                                    fontWeight: 900,
                                                    fontSize: '13px',
                                                    flexShrink: 0,
                                                    boxShadow: isAbsent
                                                        ? '0 2px 6px rgba(220, 38, 38, 0.25)'
                                                        : (isCompleted ? '0 2px 6px rgba(22, 163, 74, 0.25)' : 'none')
                                                }}
                                            >
                                                {isAbsent ? '✕' : (isCompleted ? '✓' : '')}
                                            </div>
                                            <div style={{minWidth: 0, flex: 1}}>
                                                <div style={{display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap'}}>
                                                    <b style={{fontSize: '12.5px', color: '#0f172a', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>
                                                        {emp.name}
                                                    </b>
                                                    {emp.manager_attendance_only && (
                                                        <span style={{
                                                            fontSize: '9.5px',
                                                            padding: '1px 6px',
                                                            borderRadius: '4px',
                                                            background: '#e0e7ff',
                                                            color: '#3730a3',
                                                            fontWeight: 700
                                                        }}>
                                                            Manual
                                                        </span>
                                                    )}
                                                </div>
                                                <small style={{display: 'block', fontSize: '10.5px', color: '#64748b'}}>
                                                    {emp.employee_code} · {emp.designation || 'Staff'}
                                                </small>
                                                {empPendingLeave && (
                                                    <span style={{
                                                        display: 'inline-block',
                                                        fontSize: '9.5px',
                                                        padding: '1px 6px',
                                                        borderRadius: '4px',
                                                        background: '#fef3c7',
                                                        color: '#b45309',
                                                        fontWeight: 700,
                                                        marginTop: '2px'
                                                    }}>
                                                        ⏳ રજા અરજી પેન્ડિંગ ({empPendingLeave.day_part?.replace('_', ' ')})
                                                    </span>
                                                )}
                                            </div>
                                        </label>

                                        {/* Status Badge */}
                                        {isCompleted ? (
                                            <span
                                                onClick={() => {
                                                    setQuickSelectEmpId(isSelectedForConfirm ? null : emp.id);
                                                    setQuickDayType(isAbsent ? 'absent' : (isHalfDay ? 'half_day' : 'full_day'));
                                                }}
                                                style={{
                                                    fontSize: '10.5px',
                                                    fontWeight: 800,
                                                    padding: '3px 8px',
                                                    borderRadius: '6px',
                                                    background: isAbsent ? '#fee2e2' : (isHalfDay ? '#fef3c7' : '#dcfce7'),
                                                    color: isAbsent ? '#991b1b' : (isHalfDay ? '#92400e' : '#166534'),
                                                    border: isAbsent ? '1px solid #fca5a5' : (isHalfDay ? '1px solid #fde68a' : '1px solid #86efac'),
                                                    cursor: 'pointer',
                                                    whiteSpace: 'nowrap'
                                                }}
                                                title="Click to switch Full Day / Half Day / Absent"
                                            >
                                                {isAbsent
                                                    ? (currentLang === 'en' ? '❌ Absent' : '❌ Absent (ગેરહાજર)')
                                                    : (isHalfDay
                                                        ? (currentLang === 'en' ? '🌗 Half Day' : '🌗 Half Day (અડધો દિવસ)')
                                                        : (currentLang === 'en' ? '✅ Full Day' : '✅ Full Day (આખો દિવસ)'))}
                                            </span>
                                        ) : (
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setQuickSelectEmpId(isSelectedForConfirm ? null : emp.id);
                                                    setQuickDayType('full_day');
                                                }}
                                                style={{
                                                    fontSize: '10.5px',
                                                    fontWeight: 800,
                                                    padding: '4px 9px',
                                                    borderRadius: '6px',
                                                    background: isSelectedForConfirm ? '#f59e0b' : '#fff1f2',
                                                    color: isSelectedForConfirm ? '#ffffff' : '#be123c',
                                                    border: isSelectedForConfirm ? '1px solid #d97706' : '1px solid #fecdd3',
                                                    cursor: 'pointer',
                                                    whiteSpace: 'nowrap'
                                                }}
                                            >
                                                {currentLang === 'en' ? '⬜ Pending (Mark)' : '⬜ બાકી (પૂરો કરો)'}
                                            </button>
                                        )}
                                    </div>

                                    {/* Inline Full Day / Half Day / Absent Confirmation Box when checkbox is clicked */}
                                    {isSelectedForConfirm && (
                                        <div style={{
                                            marginTop: '4px',
                                            paddingTop: '8px',
                                            borderTop: '1px dashed #cbd5e1',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'space-between',
                                            gap: '6px',
                                            flexWrap: 'wrap'
                                        }}>
                                            <div style={{display: 'flex', gap: '5px', flex: 1, minWidth: '200px'}}>
                                                <button
                                                    type="button"
                                                    onClick={() => setQuickDayType('full_day')}
                                                    style={{
                                                        flex: 1,
                                                        padding: '6px 4px',
                                                        borderRadius: '8px',
                                                        fontSize: '10.5px',
                                                        fontWeight: 800,
                                                        cursor: 'pointer',
                                                        border: quickDayType === 'full_day' ? '1.5px solid #16a34a' : '1px solid #cbd5e1',
                                                        background: quickDayType === 'full_day' ? '#dcfce7' : '#f8fafc',
                                                        color: quickDayType === 'full_day' ? '#166534' : '#475569'
                                                    }}
                                                >
                                                    ☀️ {currentLang === 'en' ? 'Full' : 'Full (આખો)'}
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={() => setQuickDayType('half_day')}
                                                    style={{
                                                        flex: 1,
                                                        padding: '6px 4px',
                                                        borderRadius: '8px',
                                                        fontSize: '10.5px',
                                                        fontWeight: 800,
                                                        cursor: 'pointer',
                                                        border: quickDayType === 'half_day' ? '1.5px solid #d97706' : '1px solid #cbd5e1',
                                                        background: quickDayType === 'half_day' ? '#fef3c7' : '#f8fafc',
                                                        color: quickDayType === 'half_day' ? '#92400e' : '#475569'
                                                    }}
                                                >
                                                    🌗 {currentLang === 'en' ? 'Half' : 'Half (અડધો)'}
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={() => setQuickDayType('absent')}
                                                    style={{
                                                        flex: 1,
                                                        padding: '6px 4px',
                                                        borderRadius: '8px',
                                                        fontSize: '10.5px',
                                                        fontWeight: 800,
                                                        cursor: 'pointer',
                                                        border: quickDayType === 'absent' ? '1.5px solid #dc2626' : '1px solid #cbd5e1',
                                                        background: quickDayType === 'absent' ? '#fee2e2' : '#f8fafc',
                                                        color: quickDayType === 'absent' ? '#991b1b' : '#475569'
                                                    }}
                                                >
                                                    ❌ {currentLang === 'en' ? 'Absent' : 'Absent (ગેરહાજર)'}
                                                </button>
                                            </div>
                                            <button
                                                type="button"
                                                disabled={isSavingThis}
                                                onClick={() => confirmQuickAttendance(emp, quickDayType)}
                                                style={{
                                                    padding: '6px 12px',
                                                    borderRadius: '8px',
                                                    fontSize: '11px',
                                                    fontWeight: 800,
                                                    cursor: isSavingThis ? 'wait' : 'pointer',
                                                    border: 'none',
                                                    background: quickDayType === 'absent' ? '#dc2626' : (quickDayType === 'half_day' ? '#d97706' : '#16a34a'),
                                                    color: '#ffffff',
                                                    boxShadow: quickDayType === 'absent'
                                                        ? '0 2px 6px rgba(220, 38, 38, 0.3)'
                                                        : (quickDayType === 'half_day'
                                                            ? '0 2px 6px rgba(217, 119, 6, 0.3)'
                                                            : '0 2px 6px rgba(22, 163, 74, 0.3)')
                                                }}
                                            >
                                                {isSavingThis
                                                    ? (currentLang === 'en' ? 'Saving...' : 'સેવ થાય છે...')
                                                    : (currentLang === 'en' ? '✅ Confirm' : '✅ કન્ફર્મ કરો')}
                                            </button>
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            <div className="attendance-toolbar">
                <DatePicker label="Attendance date" value={date} onChange={setDate}/>
                <label><span>Employee</span><select value={employeeId} onChange={event => setEmployeeId(event.target.value)}><option value="">All employees</option>{employees.map(employee => <option key={employee.id} value={employee.id}>{employee.employee_code} · {employee.name}</option>)}</select></label>
                <label className="search-box"><span>Search</span><div><Search size={16}/><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Name or code"/></div></label>
            </div>
            {filtered.length ? (
                <>
                    {/* 🗂️ Mobile-Friendly Cards View (No Horizontal Scroll) */}
                    {viewMode === 'cards' && (
                        <div className="attendance-cards-view">
                            {filtered.map(row => {
                                const empName = row.employee?.user?.name || row.employee?.name || 'Employee';
                                const empCode = row.employee?.employee_code || '';
                                const breaks = row.breaks || [];

                                const workHoursFormatted = (() => {
                                    if (row.clock_out_at) {
                                        return (row.work_minutes / 60).toFixed(2);
                                    }
                                    if (isToday && row.clock_in_at) {
                                        const inMs = new Date(row.clock_in_at).getTime();
                                        const diffMins = Math.max(0, Math.floor((Date.now() - inMs) / 60000));
                                        const breakMins = Number(row.break_minutes || 0);
                                        const netMins = Math.max(0, diffMins - breakMins);
                                        return `${(netMins / 60).toFixed(2)}h (${currentLang === 'en' ? 'Active' : 'ચાલુ'})`;
                                    }
                                    return `${(row.work_minutes / 60).toFixed(2)}h`;
                                })();

                                const isActiveShift = !row.clock_out_at && isToday;
                                const isMissingOut = !row.clock_out_at && !isToday;

                                return (
                                    <div key={row.id} className="att-card">
                                        <div className="att-card-head">
                                            <div className="att-card-user">
                                                <div
                                                    className="att-card-avatar"
                                                    onClick={() => row.selfie_url && setSelfiePreview({url: resolveMediaUrl(row.selfie_url), employee: empName, date: row.attendance_date})}
                                                    style={{cursor: row.selfie_url ? 'pointer' : 'default'}}
                                                >
                                                    {row.selfie_url ? (
                                                        <img src={resolveMediaUrl(row.selfie_url)} alt={empName} />
                                                    ) : (
                                                        <span>{empName.slice(0, 2).toUpperCase()}</span>
                                                    )}
                                                </div>
                                                <div className="att-card-user-info">
                                                    <div className="att-card-name-row">
                                                        <b className="att-card-name">{empName}</b>
                                                        {empCode && <span className="att-card-code">{empCode}</span>}
                                                    </div>
                                                    {row.entry_source === 'manager' && (
                                                        <span className="status warning att-manager-pill">
                                                            {currentLang === 'en' ? 'Manager entry' : 'મેનેજર એન્ટ્રી'}
                                                        </span>
                                                    )}
                                                </div>
                                            </div>

                                            <div className="att-card-status-wrap">
                                                {(() => {
                                                    const activeBrk = breaks.find(b => !b.ended_at);
                                                    if (activeBrk) {
                                                        return (
                                                            <span className="status warning" style={{background: activeBrk.break_type === 'urgent_out' ? '#fee2e2' : '#fef3c7', color: activeBrk.break_type === 'urgent_out' ? '#b91c1c' : '#92400e'}}>
                                                                {activeBrk.break_type === 'urgent_out' ? '🚨 અર્જન્ટ બહાર' : '☕ બ્રેક ચાલુ'}
                                                            </span>
                                                        );
                                                    }
                                                    return (
                                                        <span className={`status ${row.status === 'present' ? 'on' : (isActiveShift ? 'on' : 'warning')}`}>
                                                            {isActiveShift
                                                                ? (currentLang === 'en' ? '🟢 Active' : '🟢 ચાલુ')
                                                                : isMissingOut
                                                                ? (currentLang === 'en' ? '⚠️ Missing Out' : '⚠️ Out બાકી')
                                                                : (row.status || '').replaceAll('_', ' ')}
                                                        </span>
                                                    );
                                                })()}
                                                {canCorrect && (
                                                    <button
                                                        type="button"
                                                        className="att-correct-icon-btn"
                                                        onClick={() => openCorrection(row)}
                                                        title={currentLang === 'en' ? 'Correct Attendance' : 'હાજરી સુધારો'}
                                                    >
                                                        <PencilLine size={13}/>
                                                    </button>
                                                )}
                                            </div>
                                        </div>

                                        <div className="att-card-metrics">
                                            <div className="att-card-metric">
                                                <span className="att-metric-lbl">{currentLang === 'en' ? 'In' : 'આવ્યા'}</span>
                                                <b className="att-metric-val">
                                                    {displayTime(row.clock_in_at)}
                                                    {row.is_late && <small className="att-late-badge">Late</small>}
                                                </b>
                                            </div>
                                            <div className="att-card-metric">
                                                <span className="att-metric-lbl">{currentLang === 'en' ? 'Out' : 'ગયા'}</span>
                                                <b className="att-metric-val">
                                                    {row.clock_out_at ? displayTime(row.clock_out_at) : (isActiveShift ? (currentLang === 'en' ? '🟢 On site' : '🟢 હાજર') : '—')}
                                                </b>
                                            </div>
                                            <div className="att-card-metric">
                                                <span className="att-metric-lbl">{currentLang === 'en' ? 'Work' : 'કામ'}</span>
                                                <b className="att-metric-val">{workHoursFormatted}</b>
                                            </div>
                                            <div className="att-card-metric">
                                                <span className="att-metric-lbl">{currentLang === 'en' ? 'Break' : 'બ્રેક'}</span>
                                                <b className="att-metric-val">{(Number(row.break_minutes || 0) / 60).toFixed(2)}h</b>
                                            </div>
                                        </div>

                                        <div className="att-card-foot">
                                            <div className="att-card-assets">
                                                {row.selfie_url && (
                                                    <button
                                                        type="button"
                                                        className="att-photo-chip"
                                                        onClick={() => setSelfiePreview({url: resolveMediaUrl(row.selfie_url), employee: empName, date: row.attendance_date, title: currentLang === 'en' ? 'Time In Selfie' : 'આવવાનો સમય સેલ્ફી'})}
                                                        title="Time In Selfie"
                                                    >
                                                        <img src={resolveMediaUrl(row.selfie_url)} alt="In" />
                                                        <span>Selfie</span>
                                                    </button>
                                                )}
                                                {breaks.filter(b => b.out_selfie_url).map((b, idx) => (
                                                    <button
                                                        key={`out-${b.id}`}
                                                        type="button"
                                                        className="att-photo-chip"
                                                        onClick={() => setSelfiePreview({
                                                            url: resolveMediaUrl(b.out_selfie_url),
                                                            employee: empName,
                                                            date: row.attendance_date,
                                                            title: `🚨 અર્જન્ટ બહાર સેલ્ફી ${idx + 1}${b.out_reason ? ` (${b.out_reason})` : ''}`
                                                        })}
                                                        title={b.out_reason || `Urgent Out ${idx + 1}`}
                                                    >
                                                        <img src={resolveMediaUrl(b.out_selfie_url)} alt="Out" />
                                                        <span>Out {idx + 1}</span>
                                                    </button>
                                                ))}
                                                {breaks.filter(b => b.return_selfie_url).map((b, idx) => (
                                                    <button
                                                        key={b.id}
                                                        type="button"
                                                        className="att-photo-chip"
                                                        onClick={() => setSelfiePreview({
                                                            url: resolveMediaUrl(b.return_selfie_url),
                                                            employee: empName,
                                                            date: row.attendance_date,
                                                            title: `${currentLang === 'en' ? 'Break Return' : 'બ્રેક રિટર્ન'} ${idx + 1}`
                                                        })}
                                                        title={`Break ${idx + 1}`}
                                                    >
                                                        <img src={resolveMediaUrl(b.return_selfie_url)} alt="Break" />
                                                        <span>Break {idx + 1}</span>
                                                    </button>
                                                ))}
                                                {row.clock_in_latitude !== null && row.clock_in_longitude !== null && (
                                                    <a
                                                        className="att-map-chip"
                                                        href={`https://maps.google.com/?q=${row.clock_in_latitude},${row.clock_in_longitude}`}
                                                        target="_blank"
                                                        rel="noreferrer"
                                                    >
                                                        <MapPin size={12}/>
                                                        <span>Map</span>
                                                    </a>
                                                )}
                                            </div>

                                            {row.work_done && (
                                                <div className="att-card-note" title={`${row.work_done}\n${row.learned || ''}`}>
                                                    <span>💬</span> {row.work_done}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}

                    {/* 📑 Desktop Table View */}
                    {viewMode === 'table' && (
                        <div className="table-wrap attendance-table-wrap">
                            <table className="attendance-table">
                                <thead>
                                    <tr>
                                        <th>Employee</th>
                                        <th>Time In Selfie</th>
                                        <th>Break Return</th>
                                        <th>Time In</th>
                                        <th>Time Out</th>
                                        <th>Work Hours</th>
                                        <th>Break Hours</th>
                                        <th>Status</th>
                                        <th>Location</th>
                                        <th>Notes</th>
                                        {canCorrect && <th/>}
                                    </tr>
                                </thead>
                                <tbody>
                                    {filtered.map(row => {
                                        const empName = row.employee?.user?.name || row.employee?.name || 'Employee';
                                        const empCode = row.employee?.employee_code || '';
                                        const breaks = row.breaks || [];

                                        return (
                                            <tr key={row.id}>
                                                <td><b>{empName}</b><small>{empCode}</small>{row.entry_source === 'manager' && <i className="status warning">Manager entered</i>}</td>
                                                <td>{row.selfie_url ? <button type="button" className="photo-preview-button" onClick={() => setSelfiePreview({url: resolveMediaUrl(row.selfie_url), employee: empName, date: row.attendance_date, title: currentLang === 'en' ? 'Time In Selfie' : 'આવવાનો સમય સેલ્ફી'})} title="Time In Selfie"><img className="selfie-thumb" src={resolveMediaUrl(row.selfie_url)} alt={`${empName} Time In selfie`}/></button> : <small>Not provided — manager entry</small>}</td>
                                                <td><span className="break-selfies">{breaks.filter(item => item.return_selfie_url).map((item, index) => <button key={item.id} type="button" className="photo-preview-button" onClick={() => setSelfiePreview({url: resolveMediaUrl(item.return_selfie_url), employee: empName, date: row.attendance_date, title: `${currentLang === 'en' ? 'Break Return' : 'બ્રેક રિટર્ન'} ${index + 1}`})} title={`Break ${index + 1} Selfie`}><img className="selfie-thumb" src={resolveMediaUrl(item.return_selfie_url)} alt={`Break return ${index + 1}`}/></button>)}{!breaks.some(item => item.return_selfie_url) && '—'}</span></td>
                                                <td>{displayTime(row.clock_in_at)}{row.is_late && <small className="danger-text">Late</small>}</td>
                                                <td>{row.clock_out_at ? displayTime(row.clock_out_at) : (isToday ? <span className="status on" style={{fontSize: '11px', padding: '2px 7px'}}>{currentLang === 'en' ? '🟢 Active Shift' : '🟢 ચાલુ શિફ્ટ'}</span> : <span className="status warning" style={{fontSize: '11px', padding: '2px 7px'}}>{currentLang === 'en' ? '⚠️ Missing Time Out' : '⚠️ Time Out બાકી'}</span>)}</td>
                                                <td>{(() => {
                                                    if (row.clock_out_at) {
                                                        return (row.work_minutes / 60).toFixed(2);
                                                    }
                                                    if (isToday && row.clock_in_at) {
                                                        const inMs = new Date(row.clock_in_at).getTime();
                                                        const diffMins = Math.max(0, Math.floor((Date.now() - inMs) / 60000));
                                                        const breakMins = Number(row.break_minutes || 0);
                                                        const netMins = Math.max(0, diffMins - breakMins);
                                                        return <span style={{color: '#16a34a', fontWeight: 700}} title="Shift in progress">{(netMins / 60).toFixed(2)} <small style={{fontSize: '10px'}}>{currentLang === 'en' ? '(Active)' : '(ચાલુ)'}</small></span>;
                                                    }
                                                    return (row.work_minutes / 60).toFixed(2);
                                                })()}</td>
                                                <td>{(Number(row.break_minutes || 0) / 60).toFixed(2)}</td>
                                                <td><i className={`status ${row.status === 'present' ? 'on' : (!row.clock_out_at && isToday ? 'on' : 'warning')}`}>{!row.clock_out_at && isToday ? (currentLang === 'en' ? 'Active Shift' : 'ચાલુ શિફ્ટ (Active)') : (row.status || '').replaceAll('_', ' ')}</i></td>
                                                <td>{row.clock_in_latitude !== null && row.clock_in_longitude !== null ? <a className="map-link" href={`https://maps.google.com/?q=${row.clock_in_latitude},${row.clock_in_longitude}`} target="_blank" rel="noreferrer"><MapPin size={14}/> Map</a> : <small>Not provided — manager entry</small>}</td>
                                                <td><span className="note-preview" title={`${row.work_done || ''}\n${row.learned || ''}${row.entry_reason ? `\nReason: ${row.entry_reason}` : ''}`}>{row.work_done || '—'}{row.entry_source === 'manager' && <small>By {row.recorded_by?.name || 'authorized user'} · {row.entry_reason}</small>}</span></td>
                                                {canCorrect && <td><button className="link" onClick={() => openCorrection(row)}><PencilLine size={15}/> Correct</button></td>}
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    )}
                </>
            ) : (
                <Empty title="No attendance records" detail="No employee timed in for the selected date and filters."/>
            )}
        </section>
        {manual && <div className="modal-backdrop" onClick={() => setManual(null)}>
            <form className="modal modal-sheet manual-attendance-modal" onSubmit={saveManual} onClick={e => e.stopPropagation()} style={{maxWidth: '620px'}}>
                <div className="panel-head">
                    <div>
                        <h2>{currentLang === 'en' ? 'Add Employee Attendance' : 'કર્મચારી હાજરી ઉમેરો (Add Attendance)'}</h2>
                        <p>{currentLang === 'en' ? 'Authorized manager attendance entry without selfie or GPS' : 'સેલ્ફી અથવા GPS વગર અધિકૃત મેનેજર દ્વારા હાજરી એન્ટ્રી'}</p>
                    </div>
                    <button type="button" className="icon-button ghost" onClick={() => setManual(null)}><X size={18}/></button>
                </div>

                <div className="modal-body-scroll">
                    <div className="audit-warning" style={{marginBottom: '10px', padding: '8px 12px', fontSize: '11px'}}>
                        <ClockAlert size={16}/>
                        <span>
                            <b>{currentLang === 'en' ? '⚠️ This action is permanently recorded in audit logs' : '⚠️ આ એક્શન ઓડિટ લોગમાં કાયમી રેકોર્ડ થશે'}</b>
                            <small>{currentLang === 'en' ? 'Your name, entry time and reason will be saved in audit log.' : 'તમારું નામ, એન્ટ્રી સમય અને દર્શાવેલ કારણ ડેટાબેઝમાં સેવ થશે.'}</small>
                        </span>
                    </div>

                    <div className="attendance-manual-grid">
                        <Field label={currentLang === 'en' ? 'Employee' : 'કર્મચારી (Employee)'}>
                            <select value={manual.employee_id} onChange={event => changeManualEmployee(event.target.value)} required>
                                {eligibleEmployees.map(employee => <option key={employee.id} value={employee.id}>{employee.employee_code} · {employee.name}</option>)}
                            </select>
                        </Field>
                        <Field label={currentLang === 'en' ? 'Attendance Date' : 'હાજરી તારીખ (Date)'}>
                            <input type="date" max={localDate()} value={manual.attendance_date} onChange={event => changeManualDate(event.target.value)} required/>
                        </Field>
                        <Field label={currentLang === 'en' ? 'Time In' : 'આવવાનો સમય (Time In)'}>
                            <input type="datetime-local" value={manual.clock_in_at} onChange={event => setManual({...manual, clock_in_at: event.target.value})} required/>
                        </Field>
                        <Field label={currentLang === 'en' ? 'Time Out' : 'જવાનો સમય (Time Out)'}>
                            <input type="datetime-local" value={manual.clock_out_at} onChange={event => setManual({...manual, clock_out_at: event.target.value})} required/>
                        </Field>
                        <Field label={currentLang === 'en' ? 'Break Minutes' : 'બ્રેક મિનિટ (Break Min)'}>
                            <input type="number" min="0" max="1439" value={manual.break_minutes} onChange={event => setManual({...manual, break_minutes: event.target.value})} required/>
                        </Field>
                        <Field label={currentLang === 'en' ? 'Reason' : 'હાજરી પૂરવાનું કારણ (Reason)'}>
                            <input
                                type="text"
                                placeholder={currentLang === 'en' ? 'e.g. Phone dead / forgot' : 'દા.ત. ફોન નહોતો / ભૂલ'}
                                value={manual.entry_reason}
                                onChange={event => setManual({...manual, entry_reason: event.target.value})}
                                required
                            />
                        </Field>
                        <div className="attendance-manual-fullrow">
                            <Field label={currentLang === 'en' ? 'Work Done' : 'કામની વિગત (Work Done)'}>
                                <textarea
                                    placeholder={currentLang === 'en' ? 'Work performed today...' : 'આજે કરેલ કામ...'}
                                    value={manual.work_done}
                                    onChange={event => setManual({...manual, work_done: event.target.value})}
                                    rows="2"
                                    required
                                />
                            </Field>
                            <Field label={currentLang === 'en' ? 'Learned' : 'નવું શીખ્યા (Learned)'}>
                                <textarea
                                    placeholder={currentLang === 'en' ? 'What was learned today...' : 'આજે શું શીખ્યા...'}
                                    value={manual.learned}
                                    onChange={event => setManual({...manual, learned: event.target.value})}
                                    rows="2"
                                    required
                                />
                            </Field>
                        </div>
                    </div>
                </div>

                <div className="modal-sticky-footer">
                    <button type="button" className="secondary modal-cancel-btn" onClick={() => setManual(null)}>
                        {currentLang === 'en' ? 'Cancel' : 'રદ કરો (Cancel)'}
                    </button>
                    <button type="submit" className="primary expense-submit-btn" disabled={savingManual}>
                        {savingManual ? (currentLang === 'en' ? 'Saving…' : 'સેવ થઈ રહ્યું છે…') : (currentLang === 'en' ? '✓ Save Attendance' : '✓ Save Attendance (હાજરી સેવ કરો)')}
                    </button>
                </div>
            </form>
        </div>}

        {correction && <div className="modal-backdrop" onClick={() => setCorrection(null)}>
            <form className="modal modal-sheet correction-modal" onSubmit={saveCorrection} onClick={e => e.stopPropagation()} style={{maxWidth: '580px'}}>
                <div className="panel-head">
                    <div>
                        <h2>{correction.had_clock_out ? (currentLang === 'en' ? 'Correct Attendance' : 'હાજરી સુધારો (Correct Attendance)') : (currentLang === 'en' ? 'Complete Time Out' : 'બાકી Time Out પૂર્ણ કરો (Complete Time Out)')}</h2>
                        <p>{correction.employee} · {correction.attendance_date}</p>
                    </div>
                    <button type="button" className="icon-button ghost" onClick={() => setCorrection(null)}><X size={18}/></button>
                </div>

                <div className="modal-body-scroll">
                    <div className="audit-warning">
                        <ClockAlert/>
                        <span>
                            <b>{currentLang === 'en' ? '⚠️ This correction will be recorded in audit log' : '⚠️ આ સુધારો ઓડિટ લોગમાં રેકોર્ડ થશે'}</b>
                            <small>{currentLang === 'en' ? 'Old time, new time and reason are permanently saved.' : 'જૂનો સમય, નવો સમય અને સુધારાનું કારણ કાયમી સેવ થશે.'}</small>
                        </span>
                    </div>

                    <Field label={currentLang === 'en' ? 'Time Out' : 'જવાનો સમય (Time Out)'}>
                        <input type="datetime-local" value={correction.clock_out_at} onChange={event => setCorrection({...correction, clock_out_at: event.target.value})} required/>
                    </Field>

                    <Field label={currentLang === 'en' ? 'Work Done' : 'કર્મચારીએ આજે શું કામ કર્યું? (Work Done)'}>
                        <textarea value={correction.work_done} onChange={event => setCorrection({...correction, work_done: event.target.value})} rows="3" required/>
                    </Field>

                    <Field label={currentLang === 'en' ? 'What Learned' : 'કર્મચારીએ આજે નવું શું શીખ્યું? (What Learned)'}>
                        <textarea value={correction.learned} onChange={event => setCorrection({...correction, learned: event.target.value})} rows="3" required/>
                    </Field>

                    <Field label={currentLang === 'en' ? 'Correction Reason' : 'સુધારાનું કારણ (Correction Reason)'}>
                        <textarea value={correction.correction_reason} onChange={event => setCorrection({...correction, correction_reason: event.target.value})} rows="2" required/>
                    </Field>
                </div>

                <div className="modal-sticky-footer">
                    <button type="button" className="secondary modal-cancel-btn" onClick={() => setCorrection(null)}>
                        {currentLang === 'en' ? 'Cancel' : 'રદ કરો (Cancel)'}
                    </button>
                    <button type="submit" className="primary expense-submit-btn" disabled={savingCorrection}>
                        {savingCorrection ? (currentLang === 'en' ? 'Saving…' : 'સેવ થઈ રહ્યું છે…') : (currentLang === 'en' ? '✓ Save Audited Correction' : '✓ Save Audited Correction (સેવ કરો)')}
                    </button>
                </div>
            </form>
        </div>}
        {selfiePreview && (
            <div className="modal-backdrop" onMouseDown={event => event.target === event.currentTarget && setSelfiePreview(null)}>
                <div className="modal attendance-photo-modal" role="dialog" aria-modal="true" aria-labelledby="time-in-selfie-title">
                    <div className="panel-head">
                        <div>
                            <h2 id="time-in-selfie-title">{selfiePreview.title || (currentLang === 'en' ? 'Selfie Preview' : 'સેલ્ફી પ્રીવ્યૂ')}</h2>
                            <p>{selfiePreview.employee} · {selfiePreview.date}</p>
                        </div>
                        <button type="button" className="icon-button ghost" onClick={() => setSelfiePreview(null)} aria-label="Close photo preview">
                            <X size={18}/>
                        </button>
                    </div>
                    <img className="attendance-photo-preview" src={selfiePreview.url} alt={`${selfiePreview.employee} ${selfiePreview.title || 'selfie'}`}/>
                </div>
            </div>
        )}

        {/* 🗺️ Live Google Maps Interactive View Modal */}
        {selectedMapEmployee && (
            <div className="modal-backdrop" onClick={() => setSelectedMapEmployee(null)}>
                <div className="modal" onClick={e => e.stopPropagation()} style={{maxWidth: '720px', padding: 0, overflow: 'hidden', borderRadius: '18px'}}>
                    <div style={{
                        padding: '14px 18px',
                        background: '#0d382d',
                        color: '#ffffff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between'
                    }}>
                        <div>
                            <h3 style={{margin: 0, fontSize: '15px', fontWeight: 800, color: '#f0fdf4'}}>
                                📍 {selectedMapEmployee.name} ({selectedMapEmployee.employee_code}) · {currentLang === 'en' ? 'Live Location' : 'લાઈવ લોકેશન'}
                            </h3>
                            <p style={{margin: '3px 0 0', fontSize: '11px', color: '#86efac'}}>
                                {selectedMapEmployee.designation} · {selectedMapEmployee.company_name} · {selectedMapEmployee.last_seen}
                            </p>
                        </div>
                        <button
                            type="button"
                            className="icon-button ghost"
                            onClick={() => setSelectedMapEmployee(null)}
                            style={{background: 'rgba(255,255,255,0.15)', color: '#ffffff'}}
                        >
                            <X size={16}/>
                        </button>
                    </div>

                    <div style={{position: 'relative', width: '100%', height: '440px', background: '#e2e8f0', touchAction: 'auto'}}>
                        <iframe
                            title={`Map for ${selectedMapEmployee.name}`}
                            width="100%"
                            height="100%"
                            frameBorder="0"
                            allowFullScreen
                            src={`https://maps.google.com/maps?q=${selectedMapEmployee.latitude},${selectedMapEmployee.longitude}${mapMode === 'roadmap' ? '' : '&t=k'}&hl=gu&z=${zoomLevel}&output=embed`}
                            style={{border: 0, width: '100%', height: '100%', touchAction: 'auto'}}
                        />

                        {/* 🚶 Animated Movement Floating Pin on Modal Map */}
                        <div style={{
                            position: 'absolute',
                            top: '12px',
                            left: '12px',
                            background: selectedMapEmployee.movement === 'bike' ? 'rgba(245, 158, 11, 0.95)' : selectedMapEmployee.movement === 'walking' ? 'rgba(2, 132, 199, 0.95)' : 'rgba(22, 163, 74, 0.95)',
                            color: '#ffffff',
                            padding: '6px 12px',
                            borderRadius: '20px',
                            fontSize: '12px',
                            fontWeight: 800,
                            boxShadow: '0 4px 12px rgba(0,0,0,0.35)',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                            zIndex: 10
                        }}>
                            <span style={{
                                fontSize: '16px',
                                display: 'inline-block',
                                animation: selectedMapEmployee.movement === 'bike' ? 'rideBike 0.8s ease-in-out infinite' : selectedMapEmployee.movement === 'walking' ? 'bounceWalk 0.7s ease-in-out infinite' : 'none'
                            }}>
                                {selectedMapEmployee.movement_icon || (selectedMapEmployee.movement === 'bike' ? '🏍️' : selectedMapEmployee.movement === 'walking' ? '🚶‍♂️' : '🧍‍♂️')}
                            </span>
                            <span>
                                {selectedMapEmployee.movement === 'bike' ? `Bike: ${Math.round(selectedMapEmployee.speed || 0)} km/h` : selectedMapEmployee.movement === 'walking' ? `Walking: ${Math.round(selectedMapEmployee.speed || 4)} km/h` : (currentLang === 'en' ? 'Stationary (On site)' : 'સ્થિર છે (સાઇટ પર)')}
                            </span>
                        </div>

                        {/* 🔘 Modal Map Layer Switcher */}
                        <div style={{
                            position: 'absolute',
                            bottom: '12px',
                            left: '12px',
                            display: 'flex',
                            gap: '4px',
                            background: 'rgba(15, 23, 42, 0.9)',
                            padding: '4px',
                            borderRadius: '10px',
                            zIndex: 10
                        }}>
                            <button
                                type="button"
                                onClick={() => setMapMode('satellite')}
                                style={{
                                    border: 0,
                                    padding: '5px 12px',
                                    fontSize: '11px',
                                    fontWeight: 700,
                                    borderRadius: '7px',
                                    cursor: 'pointer',
                                    background: mapMode === 'satellite' ? '#2563eb' : 'transparent',
                                    color: '#ffffff'
                                }}
                            >
                                🛰️ Satellite
                            </button>
                            <button
                                type="button"
                                onClick={() => setMapMode('roadmap')}
                                style={{
                                    border: 0,
                                    padding: '5px 12px',
                                    fontSize: '11px',
                                    fontWeight: 700,
                                    borderRadius: '7px',
                                    cursor: 'pointer',
                                    background: mapMode === 'roadmap' ? '#475569' : 'transparent',
                                    color: '#ffffff'
                                }}
                            >
                                🗺️ Roadmap
                            </button>
                        </div>

                        {/* 🔍 Quick Zoom Controls in Modal */}
                        <div style={{
                            position: 'absolute',
                            top: '12px',
                            right: '14px',
                            display: 'flex',
                            gap: '5px',
                            zIndex: 10
                        }}>
                            <button
                                type="button"
                                onClick={() => setZoomLevel(z => Math.min(21, z + 1))}
                                style={{
                                    width: '32px',
                                    height: '32px',
                                    borderRadius: '8px',
                                    background: 'rgba(255,255,255,0.95)',
                                    border: '1px solid #cbd5e1',
                                    color: '#0f172a',
                                    fontWeight: 900,
                                    fontSize: '18px',
                                    display: 'grid',
                                    placeItems: 'center',
                                    cursor: 'pointer',
                                    boxShadow: '0 2px 6px rgba(0,0,0,0.25)'
                                }}
                                title={currentLang === 'en' ? 'Zoom In' : 'Zoom In (નજીક લાવો)'}
                            >
                                +
                            </button>
                            <button
                                type="button"
                                onClick={() => setZoomLevel(z => Math.max(14, z - 1))}
                                style={{
                                    width: '32px',
                                    height: '32px',
                                    borderRadius: '8px',
                                    background: 'rgba(255,255,255,0.95)',
                                    border: '1px solid #cbd5e1',
                                    color: '#0f172a',
                                    fontWeight: 900,
                                    fontSize: '18px',
                                    display: 'grid',
                                    placeItems: 'center',
                                    cursor: 'pointer',
                                    boxShadow: '0 2px 6px rgba(0,0,0,0.25)'
                                }}
                                title={currentLang === 'en' ? 'Zoom Out' : 'Zoom Out (દૂર કરો)'}
                            >
                                -
                            </button>
                        </div>
                    </div>

                    <div style={{
                        padding: '12px 18px',
                        background: '#f8faf9',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        borderTop: '1px solid #e2ece5',
                        flexWrap: 'wrap',
                        gap: '10px'
                    }}>
                        <div style={{fontSize: '11px', color: '#475569'}}>
                            <b>GPS:</b> {selectedMapEmployee.latitude?.toFixed(6)}, {selectedMapEmployee.longitude?.toFixed(6)}
                            {selectedMapEmployee.accuracy && <span> (±{Math.round(selectedMapEmployee.accuracy)}m)</span>}
                        </div>
                        <div style={{display: 'flex', gap: '8px', flexWrap: 'wrap'}}>
                            <a
                                href={selectedMapEmployee.map_url}
                                target="_blank"
                                rel="noreferrer"
                                className="primary"
                                style={{textDecoration: 'none', padding: '8px 14px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '6px'}}
                            >
                                <ExternalLink size={14}/> {currentLang === 'en' ? 'Open in Maps App' : 'Maps App માં જુઓ'}
                            </a>
                            <button
                                type="button"
                                className="secondary"
                                onClick={() => setSelectedMapEmployee(null)}
                                style={{padding: '8px 14px', fontSize: '12px'}}
                            >
                                {currentLang === 'en' ? 'Close' : 'બંધ કરો'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )}
    </div>;
}
