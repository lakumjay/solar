# SolarFlow Solar Billing System - Export Package

આ પેકેજમાં સોલર બિલિંગ સિસ્ટમ સંબંધિત તમામ સોર્સ કોડ ફાઈલો અને ડેટાબેઝ ટેબલ્સનો સંપૂર્ણ ડેટા સામેલ છે.

---

## ૧. ફોલ્ડર સ્ટ્રક્ચર (Directory Structure)

### `code/` (સોર્સ કોડ ફાઈલો)
- **`app/Models/`**:
  - `SolarBill.php` — બિલ રેકોર્ડ્સ મોડેલ (Audit columns, JSON casts, relationships)
  - `SolarBillingCompany.php` — Rajeshwari Solar, Sunrise Green Energy કંપની પ્રોફાઇલ મોડેલ
  - `SolarBillingCharge.php` — Dynamic Charge/Rebate Master મોડેલ
  - `SolarBillingSetting.php` — બિલિંગ ગ્લોબલ સેટિંગ્સ મોડેલ
- **`app/Services/`**:
  - `SolarBillingEngineService.php` — કોર બિલિંગ કૅલ્ક્યુલેશન એન્જિન (Exact PGVCL formulas, dynamic master charges, due date strictly 15 days, float precision)
- **`app/Http/Controllers/`**:
  - `SolarBillingController.php` — REST API કંટ્રોલર (Create, void, toggle paid, waive interest, charge master CRUD, company CRUD)
- **`database/migrations/`**:
  - `2026_10_29_000002_create_solar_billing_tables.php` — મૂળ બિલિંગ ટેબલ્સ માઈગ્રેશન
  - `2026_10_29_000003_add_signature_and_billing_configs_to_solar_billing_companies.php`
  - `2026_10_29_000004_add_paid_amount_to_solar_bills.php`
  - `2026_10_29_000005_make_due_date_nullable_in_solar_bills.php`
  - `2026_10_29_000005_add_signature_enabled_to_solar_billing_companies.php`
  - `2026_10_29_192842_create_solar_billing_charges_table.php` — Charge Master ટેબલ
  - `2026_10_29_192848_add_interest_waived_to_solar_bills_table.php` — વ્યાજ માફી કોલમ્સ
- **`resources/js/solar/`**:
  - `pages/BillingPage.jsx` — React Wizard (Step 1 Company/Month/Upload, Step 2 Data Entry, Step 3 Live Sheet Preview, Records Tab, Charges Master Tab, Setup Tab)
  - `utils/billingEngine.js` — Client-side live calculation engine, rate derive logic, sanity validation checks
  - `components/ExactSolarBillSheet.jsx` — ૨ પેજનો ઑરિજિનલ સ્પેસિફિકેશન મુજબનો પ્રિન્ટેબલ બિલ શીટ કમ્પોનન્ટ
- **`resources/css/app.css`**:
  - બિલિંગ અને મોબાઇલ-ફર્સ્ટ UI ની સંપૂર્ણ CSS ડિઝાઈન ટોકન્સ
- **`tests/`**:
  - `tests/Unit/SolarBillingEngineTest.php` — ૧૩ યુનિટ ટેસ્ટ્સ (કૅલ્ક્યુલેશન, બેન્કિંગ યુનિટ, ટેમ્પરિંગ વેરિફિકેશન)
  - `tests/Feature/SolarBillingFlowTest.php` — ૯ ફીચર ટેસ્ટ્સ (એન્ડ-ટુ-એન્ડ બિલ જનરેશન, સિંગલ/ડબલ કંપની, રિવર્સ સિક્વન્સ)
- **`routes/web.php`**:
  - બિલિંગ સંબંધિત તમામ વેબ & API રાઉટ્સ

---

## ૨. `database/` (ડેટાબેઝ ટેબલ્સ અને ડેટા)

ટેબલ્સ:
1. **`solar_billing_companies`**: કંપની પ્રોફાઇલ્સ (Rajeshwari Solar, Sunrise Green Energy, બેંક વિગતો, સિક્વન્સ, સહી સેટિંગ્સ)
2. **`solar_billing_charges`**: Dynamic Charge / Rebate Master (Cross Subsidy, Wheeling, Banking, PPA Discount)
3. **`solar_billing_settings`**: સિસ્ટમ કન્ફિગરેશન (PPA rates, default due days, grace periods)
4. **`solar_bills`**: જનરેટ થયેલા તમામ બિલ, સ્ટેટમેન્ટ ડેટા, ઑડિટ લોગ્સ, ચુકવણી અને વ્યાજ વિગતો

ફાઈલો:
- `solar_billing_all_tables.sql` — ચારેય ટેબલ્સનું માળખું અને સંપૂર્ણ લાઈવ ડેટા (Single Import File)
- `01_solar_billing_companies.sql` — માત્ર કંપની ટેબલ
- `02_solar_billing_charges.sql` — માત્ર ચાર્જ માસ્ટર ટેબલ
- `03_solar_billing_settings.sql` — માત્ર સેટિંગ્સ ટેબલ
- `04_solar_bills.sql` — માત્ર બિલ રેકોર્ડ્સ ટેબલ
- `*.json` ફાઈલો — કોઈ પણ અન્ય સિસ્ટમમાં ઇમ્પોર્ટ કરવા માટે શુદ્ધ JSON ડેટા

---

## ૩. કેવી રીતે ઇમ્પોર્ટ કરવું (How to Import):

### SQL ડેટાબેઝ ઇમ્પોર્ટ:
```bash
# MySQL / phpMyAdmin મા સીધી આ ફાઈલ ઇમ્પોર્ટ કરી શકો છો:
mysql -u [username] -p [database_name] < database/solar_billing_all_tables.sql
```
અથવા **phpMyAdmin** માં જઈને `database/solar_billing_all_tables.sql` ફાઈલ પસંદ કરી **Import** બટન દબાવો.
